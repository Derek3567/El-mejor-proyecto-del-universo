<?php
require_once __DIR__ . '/includes/learning-tools.php';
require_once __DIR__ . '/includes/api-tools.php';

api_prepare();
api_verify_csrf();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') api_json(['error'=>'Usa una solicitud POST.'],405);
$apiKey = trim((string)env('GEMINI_API_KEY', ''));
if ($apiKey === '') api_json(['error'=>'El tutor Gemini no está configurado. Añade GEMINI_API_KEY al archivo .env del servidor.','code'=>'gemini_not_configured'],503);
if (!function_exists('curl_init')) api_json(['error'=>'El servidor necesita la extensión PHP cURL para conectar con Gemini.'],503);
$now=time();
if (!empty($_SESSION['gemini_coach_last']) && $now-(int)$_SESSION['gemini_coach_last']<15) api_json(['error'=>'Espera unos segundos antes de pedir otro consejo.'],429);
$key=(string)($_POST['lesson_key']??'');
if (!preg_match('/^s[1-3]-[0-9]{1,2}$/',$key)) api_json(['error'=>'La lección no es válida.'],422);
$attempt=(string)($_POST['attempt']??'');
$state=$_SESSION['curriculum_completed_attempts'][$attempt]??null;
if(!is_array($state)||(int)($state['user_id']??0)!==$learnUserId||($state['lesson_key']??'')!==$key||time()-(int)($state['completed_at']??0)>7200) api_json(['error'=>'El resumen expiró. Termina la lección nuevamente para pedir retroalimentación.'],400);
$total=max(0,min(3,(int)($state['quiz_total']??0)));
$score=max(0,min($total,(int)($state['quiz_score']??0)));
$seconds=max(0,min(7200,(int)($state['elapsed_seconds']??0)));
$review=is_array($state['review']??null)?$state['review']:[];$missed=array_values(array_filter($review,static fn($item)=>empty($item['is_correct'])));
$lesson=learn_curriculum_lesson($key);$lessonTitle=(string)($lesson['lesson']['title']??'esta lección');
$reviewJson=json_encode($missed,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
$camera=$state['camera']??[];$samples=max(0,(int)($camera['samples']??0));$seen=max(0,(int)($camera['seen_samples']??0));$continuity=$samples>0?(int)round($seen/$samples*100):0;
$prompt="Eres tutora de aprendizaje de Lengua de Señas Mexicana (LSM). Escribe en español una retroalimentación clara, amable y específica, con cuatro apartados: ‘Tu resultado’, ‘Lo que ya dominas’, ‘Qué repasar’ y ‘Siguiente práctica’. Lección: {$lessonTitle}. Resultado guardado: {$score} aciertos de {$total} (".((int)($state['quiz_accuracy']??0))."/100); tiempo total {$seconds} segundos; objetivos practicados ".((int)($state['items_completed']??0))."; continuidad de mano detectada {$continuity}%. La continuidad de cámara NO es precisión de señas. Respuestas incorrectas guardadas: {$reviewJson}. Menciona hasta dos errores reales con su explicación; si no hubo errores, reconoce el resultado y sugiere repaso espaciado. Da 2 ejercicios concretos basados solo en las explicaciones y fuentes de la lista. No inventes vocabulario ni corrijas una seña mirando cámara: no recibiste video, puntos ni un análisis lingüístico. Aclara que este puntaje mide el cuestionario de conocimientos, no competencia en LSM.";
$payload=json_encode(['model'=>env('GEMINI_MODEL','gemini-3.8-flash'),'input'=>$prompt,'store'=>false],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
$ch=curl_init('https://generativelanguage.googleapis.com/v1beta/interactions');
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>35,CURLOPT_HTTPHEADER=>['Content-Type: application/json','x-goog-api-key: '.$apiKey],CURLOPT_POSTFIELDS=>$payload]);
$response=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$curlError=curl_error($ch);curl_close($ch);
if ($response===false || $status<200 || $status>=300) {error_log('[Senix Gemini] HTTP '.$status.' '.$curlError.' '.substr((string)$response,0,500));api_json(['error'=>'Gemini no pudo responder ahora. Inténtalo de nuevo en un momento.'],502);}
$data=json_decode((string)$response,true);$answer=trim((string)($data['output_text']??''));
if($answer===''&&is_array($data['steps']??null))foreach($data['steps'] as $step){if(($step['type']??'')!=='model_output'||!is_array($step['content']??null))continue;foreach($step['content'] as $block)if(($block['type']??'')==='text'&&isset($block['text']))$answer.=($answer===''?'':"\n").(string)$block['text'];}
$answer=preg_replace('/\n{3,}/',"\n\n",$answer??'');
if($answer===''){error_log('[Senix Gemini] Response without output_text');api_json(['error'=>'Gemini no devolvió un consejo legible. Inténtalo de nuevo.'],502);}
$_SESSION['gemini_coach_last']=$now;
api_json(['success'=>true,'coach'=>$answer,'model'=>(string)env('GEMINI_MODEL','gemini-3.8-flash')]);

