<?php
/** Personal procedural signs. This endpoint never executes imported content. */
ob_start();
require_once __DIR__ . '/includes/api-tools.php';
api_prepare();
// Keep unexpected bootstrap output (including a database connection failure) private.
$signsResponseSent = false;
register_shutdown_function(function () use (&$signsResponseSent): void {
    if (!$signsResponseSent) {
        while (ob_get_level() > 0) ob_end_clean();
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, private');
            http_response_code(503);
        }
        echo '{"success":false,"error":"El servicio de señas no está disponible. Inténtalo de nuevo."}';
    }
});
function signs_json(array $payload, int $status = 200): never {
    global $signsResponseSent;
    $signsResponseSent = true;
    api_json($payload, $status);
}
function signs_length(string $value): int {
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : preg_match_all('/./us', $value);
}
function signs_text($value, int $min, int $max): bool {
    return is_string($value) && signs_length($value) >= $min && signs_length($value) <= $max
        && !preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value)
        && ($min === 0 || preg_match('/[^\s\x{FEFF}]/u', $value));
}
function signs_number($value, float $min, float $max): bool {
    return (is_int($value) || is_float($value)) && is_finite((float)$value) && $value >= $min && $value <= $max;
}
function signs_keys($value, array $required, array $optional = []): bool {
    if (!$value instanceof stdClass) return false;
    $keys = array_keys(get_object_vars($value));
    return !array_diff($required, $keys) && !array_diff($keys, array_merge($required, $optional));
}
function signs_triple($value, float $min, float $max): bool {
    if (!is_array($value) || count($value) !== 3 || array_keys($value) !== [0, 1, 2]) return false;
    foreach ($value as $number) if (!signs_number($number, $min, $max)) return false;
    return true;
}
function signs_hand($hand): bool {
    if ($hand === null) return true;
    $fingers = ['thumb', 'index', 'middle', 'ring', 'pinky'];
    if (!signs_keys($hand, ['position', 'rotation', 'fingers', 'spread', 'thumbOpposition'])
        || !signs_triple($hand->position, -8, 8) || !signs_triple($hand->rotation, -360, 360)
        || !signs_number($hand->thumbOpposition, -90, 180)
        || !signs_keys($hand->fingers, $fingers) || !signs_keys($hand->spread, $fingers)) return false;
    foreach ($fingers as $finger) {
        if (!signs_triple($hand->fingers->{$finger}, -30, 160) || !signs_number($hand->spread->{$finger}, -90, 90)) return false;
    }
    return true;
}
/** Returns field errors only, never user content or a database diagnostic. */
function signs_validate($sign): array {
    $required = ['id', 'label', 'kind', 'description', 'instructions', 'status', 'duration', 'body', 'frames'];
    if (!signs_keys($sign, $required, ['aliases', 'sourceUrls'])) return ['La seña debe contener exactamente los campos del formato SENIX.'];
    $errors = [];
    if (!signs_text($sign->id, 1, 100)) $errors[] = 'id debe tener de 1 a 100 caracteres.';
    if (!signs_text($sign->label, 1, 120)) $errors[] = 'label debe tener de 1 a 120 caracteres.';
    if (!signs_text($sign->description, 0, 3000)) $errors[] = 'description debe tener hasta 3000 caracteres.';
    if (!in_array($sign->kind, ['letter', 'number', 'word', 'phrase'], true)) $errors[] = 'kind no es válido.';
    if (!in_array($sign->status, ['draft', 'reviewed'], true)) $errors[] = 'status no es válido.';
    if (!signs_number($sign->duration, 0.5, 60)) $errors[] = 'duration debe estar entre 0.5 y 60 segundos.';
    if (!is_bool($sign->body)) $errors[] = 'body debe ser un booleano.';
    if (!is_array($sign->instructions) || count($sign->instructions) > 30) $errors[] = 'instructions admite hasta 30 instrucciones.';
    else foreach ($sign->instructions as $item) if (!signs_text($item, 1, 500)) { $errors[] = 'Cada instrucción debe tener de 1 a 500 caracteres.'; break; }
    if (property_exists($sign, 'aliases')) {
        if (!is_array($sign->aliases) || count($sign->aliases) > 40) $errors[] = 'aliases admite hasta 40 nombres.';
        else foreach ($sign->aliases as $item) if (!signs_text($item, 1, 120)) { $errors[] = 'Cada alias debe tener de 1 a 120 caracteres.'; break; }
    }
    if (property_exists($sign, 'sourceUrls')) {
        if (!is_array($sign->sourceUrls) || count($sign->sourceUrls) > 20) $errors[] = 'sourceUrls admite hasta 20 referencias HTTPS.';
        else foreach ($sign->sourceUrls as $url) {
            $parts = is_string($url) ? parse_url($url) : false;
            if (!signs_text($url, 1, 2048) || preg_match('/[\s\\\\]/u', $url)
                || !filter_var($url, FILTER_VALIDATE_URL) || !$parts
                || strtolower($parts['scheme'] ?? '') !== 'https' || empty($parts['host'])
                || isset($parts['user']) || isset($parts['pass'])) {
                $errors[] = 'Las referencias deben ser URLs HTTPS sin credenciales.'; break;
            }
        }
    }
    if (!is_array($sign->frames) || count($sign->frames) < 2 || count($sign->frames) > 120) {
        $errors[] = 'frames debe contener entre 2 y 120 poses completas.';
    } else {
        $previous = -1;
        foreach ($sign->frames as $frame) {
            if (!signs_keys($frame, ['t', 'cue', 'right', 'left']) || !signs_number($frame->t, 0, 1)
                || $frame->t <= $previous || !signs_text($frame->cue, 0, 500)
                || !signs_hand($frame->right) || !signs_hand($frame->left)
                || ($frame->right === null && $frame->left === null)) {
                $errors[] = 'Cada pose necesita un tiempo creciente, una indicación y al menos una mano con todos sus valores dentro del rango.';
                break;
            }
            $previous = $frame->t;
        }
        $first = $sign->frames[0]; $last = $sign->frames[count($sign->frames) - 1];
        if (!$first instanceof stdClass || !$last instanceof stdClass
            || !isset($first->t, $last->t) || !signs_number($first->t, 0, 0) || !signs_number($last->t, 1, 1)) {
            $errors[] = 'La primera pose debe empezar en 0 y la última terminar en 1.';
        }
    }
    return $errors;
}
function signs_id($value): ?int {
    if (!is_string($value) || !preg_match('/^[1-9][0-9]{0,18}$/D', $value)) return null;
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return $id === false ? null : $id;
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/bootstrap.php';
api_prepare();
if (!$auth->isLoggedIn() || (int)currentUserId() < 1) {
    signs_json(['success' => false, 'error' => 'Inicia sesión para gestionar tus señas.', 'code' => 'session_expired'], 401);
}
$userId = (int)currentUserId();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    signs_json(['success' => false, 'error' => 'Método no permitido.'], 405);
}
if ($method === 'POST') {
    // Verify explicitly so every exit passes through signs_json and shutdown remains safe.
    $token = $_POST['csrf_token'] ?? null;
    $stored = $_SESSION['learn_csrf'] ?? null;
    if (!is_string($token) || !is_string($stored) || $token === '' || $stored === '' || !hash_equals($stored, $token)) {
        signs_json(['success' => false, 'error' => 'Tu sesión expiró. Recarga la página e inténtalo de nuevo.', 'code' => 'csrf_expired'], 419);
    }
}
try {
    $pdo->exec('CREATE TABLE IF NOT EXISTS custom_sign_animations (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        label VARCHAR(120) NOT NULL,
        payload_json MEDIUMTEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_custom_sign_user (user_id),
        CONSTRAINT fk_custom_sign_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    if ($method === 'GET') {
        $query = $pdo->prepare('SELECT id, label, payload_json, updated_at FROM custom_sign_animations WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 100');
        $query->execute([$userId]);
        $signs = [];
        foreach ($query->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $payload = json_decode($row['payload_json'], false, 32, JSON_THROW_ON_ERROR);
            $signs[] = ['id' => (int)$row['id'], 'label' => $row['label'], 'payload' => $payload, 'updated_at' => $row['updated_at']];
        }
        signs_json(['success' => true, 'signs' => $signs]);
    }
    $action = $_POST['action'] ?? null;
    if (!is_string($action) || !in_array($action, ['save', 'delete'], true)) {
        signs_json(['success' => false, 'error' => 'Acción no válida.'], 400);
    }
    $id = isset($_POST['id']) && $_POST['id'] !== '' ? signs_id($_POST['id']) : null;
    if ((isset($_POST['id']) && $_POST['id'] !== '' && $id === null) || ($action === 'delete' && $id === null)) {
        signs_json(['success' => false, 'error' => 'Identificador no válido.'], 400);
    }
    if ($action === 'delete') {
        $query = $pdo->prepare('DELETE FROM custom_sign_animations WHERE id = ? AND user_id = ?');
        $query->execute([$id, $userId]);
        if ($query->rowCount() !== 1) signs_json(['success' => false, 'error' => 'No se encontró esta seña en tu colección.'], 404);
        signs_json(['success' => true]);
    }
    $raw = $_POST['payload'] ?? null;
    if (!is_string($raw) || $raw === '') signs_json(['success' => false, 'error' => 'Falta el objeto JSON de la seña.'], 400);
    if (strlen($raw) > 512 * 1024) signs_json(['success' => false, 'error' => 'El JSON supera el límite de 512 KiB.'], 413);
    try { $payload = json_decode($raw, false, 32, JSON_THROW_ON_ERROR); }
    catch (JsonException $error) { signs_json(['success' => false, 'error' => 'El JSON no es válido.'], 422); }
    $errors = signs_validate($payload);
    if ($errors) signs_json(['success' => false, 'error' => 'Revisa los datos de la seña.', 'errors' => $errors], 422);
    // A personal edit cannot certify linguistic correctness.
    $payload->status = 'draft';
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $pdo->beginTransaction();
    // Serialize all writes for this user, including requests from distinct sessions.
    $query = $pdo->prepare('SELECT id FROM users WHERE id = ? FOR UPDATE');
    $query->execute([$userId]);
    if ($query->fetchColumn() === false) throw new RuntimeException('User unavailable.');
    if ($id !== null) {
        $query = $pdo->prepare('SELECT id FROM custom_sign_animations WHERE id = ? AND user_id = ? FOR UPDATE');
        $query->execute([$id, $userId]);
        if ($query->fetchColumn() === false) {
            $pdo->rollBack();
            signs_json(['success' => false, 'error' => 'No se encontró esta seña en tu colección.'], 404);
        }
        $query = $pdo->prepare('UPDATE custom_sign_animations SET label = ?, payload_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?');
        $query->execute([$payload->label, $json, $id, $userId]);
    } else {
        $query = $pdo->prepare('SELECT COUNT(*) FROM custom_sign_animations WHERE user_id = ?');
        $query->execute([$userId]);
        if ((int)$query->fetchColumn() >= 100) {
            $pdo->rollBack();
            signs_json(['success' => false, 'error' => 'Tu colección admite hasta 100 señas. Exporta o elimina una antes de añadir otra.'], 409);
        }
        $query = $pdo->prepare('INSERT INTO custom_sign_animations (user_id, label, payload_json) VALUES (?, ?, ?)');
        $query->execute([$userId, $payload->label, $json]);
        $id = (int)$pdo->lastInsertId();
    }
    $pdo->commit();
    signs_json(['success' => true, 'id' => $id]);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('[Senix signs API] Request failed: ' . get_class($error));
    signs_json(['success' => false, 'error' => 'No se pudo guardar o recuperar la colección. Inténtalo de nuevo.'], 503);
}
