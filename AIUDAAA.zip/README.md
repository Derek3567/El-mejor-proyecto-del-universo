# Senix

Aplicación PHP de aprendizaje de Lengua de Señas Mexicana (LSM), con cuentas, progreso, comunidad y una guía de manos en 3D.

## Actualización incluida

- La portada usa una paleta y tipografía más cercanas al centro de aprendizaje.
- Comunidad incorpora un tablón de publicaciones, comentarios, imágenes y eventos de logros, niveles y lecciones.
- Se pueden crear chats grupales con amistades aceptadas.
- Hay más opciones de marcos de perfil.
- Las lecciones incluyen práctica de cámara con MediaPipe Hands, guía 3D, repaso de vocabulario y resumen con aciertos y tiempo.
- El reconocimiento de cámara es una ayuda aproximada para algunas formas estáticas de letras; no certifica la ejecución correcta de señas LSM ni reconoce movimientos completos.
- Gemini puede dar sugerencias de estudio después de una lección, si se configura una clave.

## Despliegue

1. Conserva una copia de seguridad de los archivos que estén en el hosting.
2. Descomprime el ZIP y sube el contenido de `htdocs` al directorio web, conservando la configuración de base de datos que ya utiliza el sitio.
3. Abre el sitio por HTTPS. El navegador requiere HTTPS para permitir el acceso a la cámara.
4. Comprueba que PHP tenga PDO MySQL, cURL para Gemini, y Fileinfo/GD para subir imágenes. La base de datos crea las tablas nuevas cuando se usan las funciones correspondientes.
5. Para activar los consejos de Gemini, crea un `.env` en la raíz del sitio con `GEMINI_API_KEY=tu_clave` y, opcionalmente, `GEMINI_MODEL=gemini-3.8-flash`. No publiques la clave en archivos JavaScript.

Las tablas existentes y el contenido de lecciones se conservan. El archivo `.env.example` sirve como referencia; no contiene claves.

## Contenido y precisión

El visor 3D y el contenido de señas del proyecto son material didáctico inicial. Requieren revisión por personas competentes en LSM antes de presentarse como una referencia lingüística validada. MediaPipe localiza puntos de la mano y permite practicar el encuadre; el cuestionario mide el repaso del vocabulario. La cámara no evalúa la precisión de una seña completa.
