<?php
ob_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/api-tools.php';
api_prepare();
api_require_login($auth, 'Tu sesión expiró. Recarga la página para volver a Comunidad.');
$uid=(int)currentUserId();
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
header('Cache-Control: no-store, private');
function video_json(array $data,int $status=200): never { http_response_code($status); echo json_encode($data,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_UNICODE); exit; }
function video_schema(PDO $db): void {
 static $ready=false;if($ready)return;
 $db->exec("CREATE TABLE IF NOT EXISTS community_video_queue (user_id INT UNSIGNED NOT NULL PRIMARY KEY,joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_video_queue_joined(joined_at),CONSTRAINT fk_video_queue_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE IF NOT EXISTS community_video_rooms (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_low_id INT UNSIGNED NOT NULL,user_high_id INT UNSIGNED NOT NULL,initiator_id INT UNSIGNED NOT NULL,status ENUM('active','ended') NOT NULL DEFAULT 'active',created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,ended_at DATETIME DEFAULT NULL,KEY idx_video_room_low(user_low_id,status),KEY idx_video_room_high(user_high_id,status),CONSTRAINT fk_video_room_low FOREIGN KEY(user_low_id) REFERENCES users(id) ON DELETE CASCADE,CONSTRAINT fk_video_room_high FOREIGN KEY(user_high_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE IF NOT EXISTS community_video_signals (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,room_id BIGINT UNSIGNED NOT NULL,sender_id INT UNSIGNED NOT NULL,recipient_id INT UNSIGNED NOT NULL,signal_type ENUM('offer','answer','ice') NOT NULL,payload MEDIUMTEXT NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_video_signal_recipient(room_id,recipient_id,id),CONSTRAINT fk_video_signal_room FOREIGN KEY(room_id) REFERENCES community_video_rooms(id) ON DELETE CASCADE,CONSTRAINT fk_video_signal_sender FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,CONSTRAINT fk_video_signal_recipient_user FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE IF NOT EXISTS community_video_blocks (blocker_id INT UNSIGNED NOT NULL,blocked_id INT UNSIGNED NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(blocker_id,blocked_id),CONSTRAINT fk_video_blocker FOREIGN KEY(blocker_id) REFERENCES users(id) ON DELETE CASCADE,CONSTRAINT fk_video_blocked FOREIGN KEY(blocked_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE IF NOT EXISTS community_video_reports (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,room_id BIGINT UNSIGNED NOT NULL,reporter_id INT UNSIGNED NOT NULL,reported_id INT UNSIGNED NOT NULL,reason VARCHAR(80) NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_video_report_created(created_at),CONSTRAINT fk_video_report_room FOREIGN KEY(room_id) REFERENCES community_video_rooms(id) ON DELETE CASCADE,CONSTRAINT fk_video_reporter FOREIGN KEY(reporter_id) REFERENCES users(id) ON DELETE CASCADE,CONSTRAINT fk_video_reported FOREIGN KEY(reported_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $ready=true;
}
function video_member_room(PDO $db,int $roomId,int $uid): ?array {
 $q=$db->prepare("SELECT r.*,IF(r.user_low_id=?,r.user_high_id,r.user_low_id) peer_id,u.username peer_username,u.full_name peer_name FROM community_video_rooms r JOIN users u ON u.id=IF(r.user_low_id=?,r.user_high_id,r.user_low_id) WHERE r.id=? AND (r.user_low_id=? OR r.user_high_id=?) LIMIT 1");
 $q->execute([$uid,$uid,$roomId,$uid,$uid]);return $q->fetch(PDO::FETCH_ASSOC)?:null;
}
video_schema($pdo);
$method=$_SERVER['REQUEST_METHOD']??'GET';
$action=(string)(($method==='POST'?$_POST['action']??'':$_GET['action']??''));
if($method==='POST')api_verify_csrf();
if($action==='queue'&&$method==='POST'){
 $active=$pdo->prepare("SELECT id FROM community_video_rooms WHERE status='active' AND (user_low_id=? OR user_high_id=?) ORDER BY id DESC LIMIT 1");$active->execute([$uid,$uid]);$roomId=(int)$active->fetchColumn();
 if($roomId){$room=video_member_room($pdo,$roomId,$uid);video_json(['success'=>true,'matched'=>true,'room_id'=>$roomId,'initiator'=>(int)$room['initiator_id']===$uid,'peer'=>['id'=>(int)$room['peer_id'],'username'=>$room['peer_username'],'name'=>$room['peer_name']]]);}
 try{
  $pdo->beginTransaction();
  $pdo->exec("DELETE FROM community_video_queue WHERE joined_at < DATE_SUB(UTC_TIMESTAMP(),INTERVAL 3 MINUTE)");
  $sql="SELECT q.user_id FROM community_video_queue q JOIN users u ON u.id=q.user_id AND u.is_active=1 WHERE q.user_id<>? AND NOT EXISTS(SELECT 1 FROM community_video_blocks b WHERE (b.blocker_id=? AND b.blocked_id=q.user_id) OR (b.blocker_id=q.user_id AND b.blocked_id=?)) ORDER BY RAND() LIMIT 1 FOR UPDATE";
  $candidate=$pdo->prepare($sql);$candidate->execute([$uid,$uid,$uid]);$peer=(int)$candidate->fetchColumn();
  if($peer>0){
   $low=min($uid,$peer);$high=max($uid,$peer);
   $insert=$pdo->prepare("INSERT INTO community_video_rooms(user_low_id,user_high_id,initiator_id,status,created_at) VALUES(?,?,?,'active',UTC_TIMESTAMP())");$insert->execute([$low,$high,$uid]);$roomId=(int)$pdo->lastInsertId();
   $remove=$pdo->prepare('DELETE FROM community_video_queue WHERE user_id IN (?,?)');$remove->execute([$uid,$peer]);
   $name=$pdo->prepare('SELECT username,full_name FROM users WHERE id=? AND is_active=1');$name->execute([$peer]);$person=$name->fetch(PDO::FETCH_ASSOC);
   if(!$person)throw new RuntimeException('La otra persona ya no está disponible.');
   $pdo->commit();video_json(['success'=>true,'matched'=>true,'room_id'=>$roomId,'initiator'=>true,'peer'=>['id'=>$peer,'username'=>$person['username'],'name'=>$person['full_name']?:$person['username']]]);
  }
  $q=$pdo->prepare('INSERT INTO community_video_queue(user_id,joined_at) VALUES(?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE joined_at=UTC_TIMESTAMP()');$q->execute([$uid]);$pdo->commit();video_json(['success'=>true,'matched'=>false,'waiting'=>true]);
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('[Senix video queue] '.$e->getMessage());video_json(['error'=>'No se pudo buscar una conexión. Inténtalo nuevamente.'],500);}
}
if($action==='poll'&&$method==='GET'){
 $roomId=(int)($_GET['room_id']??0);
 if($roomId<1){$q=$pdo->prepare("SELECT id FROM community_video_rooms WHERE status='active' AND (user_low_id=? OR user_high_id=?) ORDER BY id DESC LIMIT 1");$q->execute([$uid,$uid]);$roomId=(int)$q->fetchColumn();}
 if($roomId<1){$q=$pdo->prepare('SELECT 1 FROM community_video_queue WHERE user_id=?');$q->execute([$uid]);video_json(['success'=>true,'waiting'=>(bool)$q->fetchColumn()]);}
 $room=video_member_room($pdo,$roomId,$uid);if(!$room)video_json(['success'=>false,'status'=>'ended'],200);
 if($room['status']!=='active')video_json(['success'=>true,'status'=>'ended','room_id'=>$roomId]);
 $after=max(0,(int)($_GET['after_id']??0));$q=$pdo->prepare("SELECT id,signal_type,payload FROM community_video_signals WHERE room_id=? AND recipient_id=? AND id>? ORDER BY id LIMIT 50");$q->execute([$roomId,$uid,$after]);$signals=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $signal){$payload=json_decode((string)$signal['payload'],true);if(is_array($payload))$signals[]=['id'=>(int)$signal['id'],'type'=>$signal['signal_type'],'payload'=>$payload];}
 $pdo->prepare('UPDATE community_video_queue SET joined_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$uid]);
 video_json(['success'=>true,'status'=>'active','room_id'=>$roomId,'initiator'=>(int)$room['initiator_id']===$uid,'peer'=>['id'=>(int)$room['peer_id'],'username'=>$room['peer_username'],'name'=>$room['peer_name']],'signals'=>$signals]);
}
if($action==='signal'&&$method==='POST'){
 $roomId=(int)($_POST['room_id']??0);$type=(string)($_POST['signal_type']??'');$payload=(string)($_POST['payload']??'');
 if(!in_array($type,['offer','answer','ice'],true)||strlen($payload)>20000)video_json(['error'=>'La señal de conexión no tiene un formato válido.'],422);
 $decoded=json_decode($payload,true);if(!is_array($decoded))video_json(['error'=>'La señal de conexión no se pudo leer.'],422);
 $room=video_member_room($pdo,$roomId,$uid);if(!$room||$room['status']!=='active')video_json(['error'=>'La videollamada ya terminó.'],410);
 $recipient=(int)$room['peer_id'];$insert=$pdo->prepare('INSERT INTO community_video_signals(room_id,sender_id,recipient_id,signal_type,payload) VALUES(?,?,?,?,?)');$insert->execute([$roomId,$uid,$recipient,$type,$payload]);video_json(['success'=>true]);
}
if($action==='leave'&&$method==='POST'){
 $roomId=(int)($_POST['room_id']??0);if($roomId>0)$pdo->prepare("UPDATE community_video_rooms SET status='ended',ended_at=UTC_TIMESTAMP() WHERE id=? AND status='active' AND (user_low_id=? OR user_high_id=?)")->execute([$roomId,$uid,$uid]);
 $pdo->prepare('DELETE FROM community_video_queue WHERE user_id=?')->execute([$uid]);video_json(['success'=>true]);
}
if($action==='report'&&$method==='POST'){
 $roomId=(int)($_POST['room_id']??0);$room=video_member_room($pdo,$roomId,$uid);if(!$room||$room['status']!=='active')video_json(['error'=>'La videollamada ya terminó.'],410);
 $peer=(int)$room['peer_id'];$reason=trim((string)($_POST['reason']??'Conducta inapropiada'));if(strlen($reason)>80)$reason=substr($reason,0,80);
 $pdo->beginTransaction();try{$pdo->prepare('INSERT IGNORE INTO community_video_blocks(blocker_id,blocked_id) VALUES(?,?)')->execute([$uid,$peer]);$pdo->prepare('INSERT INTO community_video_reports(room_id,reporter_id,reported_id,reason) VALUES(?,?,?,?)')->execute([$roomId,$uid,$peer,$reason]);$pdo->prepare("UPDATE community_video_rooms SET status='ended',ended_at=UTC_TIMESTAMP() WHERE id=?")->execute([$roomId]);$pdo->prepare('DELETE FROM community_video_queue WHERE user_id IN (?,?)')->execute([$uid,$peer]);$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
 video_json(['success'=>true]);
}
video_json(['error'=>'Acción o método no permitido.'],405);
