<?php
require_once __DIR__ . '/includes/learning-tools.php';
learn_header('Reto de memoria', 'Relaciona una letra con la descripción de su forma manual.', ['mini-game.css?v=20261026-2']);
?>
<section class="memory-game" aria-labelledby="memory-title">
  <div class="memory-intro"><span class="eyebrow">MINIJUEGO · DACTILOLOGÍA</span><h2 id="memory-title">Señas en pareja</h2><p>Destapa dos cartas. Relaciona la letra con una descripción de su forma manual. Son pistas introductorias; la práctica guiada y la validación de LSM requieren observar el movimiento y la orientación.</p></div>
  <div class="memory-toolbar"><span id="memory-moves">0 intentos</span><span id="memory-pairs">0 de 6 pares</span><button id="memory-restart" type="button">Nueva partida ↻</button></div>
  <div class="memory-board" id="memory-board" aria-label="Cartas del juego"></div>
  <p class="memory-status" id="memory-status" role="status" aria-live="polite">Selecciona dos cartas para comenzar.</p>
  <a class="memory-back" href="practice.php">← Volver al laboratorio</a>
</section>
<script src="<?= learn_h(asset('js/mini-game.js')) ?>?v=20261026-2" defer></script>
<?php learn_footer(); ?>
