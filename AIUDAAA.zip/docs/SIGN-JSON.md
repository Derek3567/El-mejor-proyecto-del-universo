# SENIX · Formato de señas procedurales

El taller (`sign-builder.php`) convierte controles de dedos, muñecas y posturas clave en un objeto JSON que reproduce el visor Three.js. Puedes descargarlo, importarlo y guardar borradores privados en tu cuenta.

Las animaciones se identifican como **pendientes de validación en LSM**. Un modelo de manos no representa por sí solo todas las expresiones faciales y corporales de una lengua de señas. Revisa las animaciones con personas competentes en LSM antes de usarlas como material de enseñanza validado.

## Cómo construir una animación

1. Escribe el nombre, el tipo de seña, una descripción e instrucciones breves.
2. Selecciona la postura inicial. Activa la mano derecha, la izquierda o ambas.
3. Elige una forma inicial: abierta, puño, índice o pinza. Selecciona cada dedo y ajusta sus tres articulaciones.
4. Ajusta la separación de los dedos y la oposición del pulgar. Usa ubicación y orientación para situar la mano frente al cuerpo.
5. Selecciona la postura final y ajústala. Para una seña estática, las dos posturas deben coincidir.
6. Añade posturas intermedias o duplica una existente. Indica cuándo ocurre cada una y qué debe observar quien aprende.
7. Reproduce a velocidad lenta, gira la cámara y revisa la forma desde distintos ángulos.
8. Guarda el borrador en tu cuenta o descarga el JSON. Los cambios no se guardan automáticamente.

## Objeto principal

| Propiedad | Contenido |
| --- | --- |
| `id` | Identificador estable de la animación. El taller asigna uno nuevo al importar o copiar. |
| `label` | Nombre visible. |
| `kind` | `letter`, `number`, `word` o `phrase`. |
| `aliases` | Lista de nombres alternativos para localizar la seña. |
| `description` | Descripción breve de la seña. |
| `instructions` | Lista ordenada de instrucciones de lectura humana. |
| `status` | Los borradores del taller usan `draft`. |
| `duration` | Duración de un ciclo, en segundos. |
| `body` | `true` muestra una referencia de cabeza y torso. |
| `frames` | Posturas completas ordenadas por tiempo. Se necesitan al menos dos: `t: 0` y `t: 1`. |

Cada postura contiene `t`, `cue`, `right` y `left`. `t` representa una fracción de la duración: `0.5` equivale a la mitad. `cue` describe ese paso. Una mano oculta se escribe como `null`; debe haber al menos una visible. Cada mano visible contiene todos sus datos, aunque sean iguales a la postura anterior.

## Mano y sistema de coordenadas

| Propiedad | Contenido |
| --- | --- |
| `position` | `[x, y, z]`, ubicación de la muñeca en unidades del escenario. |
| `rotation` | `[x, y, z]`, orientación de la muñeca en **grados**. |
| `fingers` | Objeto con `thumb`, `index`, `middle`, `ring` y `pinky`. Cada valor tiene tres ángulos en grados. |
| `spread` | Separación lateral, en grados, para los cinco dedos. |
| `thumbOpposition` | Oposición del pulgar en grados. |

X es el eje lateral; Y aumenta hacia arriba; Z representa la profundidad. La cámara frontal mira hacia el escenario. Derecha e izquierda corresponden a la persona que realiza la seña. Cambiar de cámara no cambia los datos de las manos.

Los ángulos de `thumb` corresponden a **CMC, MCP, IP**. En los otros dedos corresponden a **MCP, PIP, DIP**: base, articulación intermedia y punta. Cero mantiene la articulación extendida y los valores positivos la flexionan hacia la palma. El visor adapta la geometría a la mano izquierda.

El taller admite flexión entre −30° y 160°, separación entre −90° y 90°, oposición entre −90° y 180°, orientación entre −360° y 360° y posición entre −8 y 8. Estos límites técnicos permiten ajustar el modelo; no garantizan que una postura sea anatómicamente correcta.

La ubicación inicial es `[0,-1,0]` para la mano derecha y `[-1.5,-1,0]` para la izquierda. La cabeza y el torso solo ofrecen una referencia espacial para colocar las manos.

## Ejemplo mínimo

Este ejemplo muestra una mano abierta estática. Es una plantilla técnica, no una seña validada de LSM.

```json
{
  "id": "ejemplo-mano-abierta",
  "label": "Plantilla de mano abierta",
  "kind": "word",
  "aliases": [],
  "description": "Plantilla para construir una nueva animación.",
  "instructions": ["Observa la postura y ajusta cada dedo."],
  "status": "draft",
  "duration": 4,
  "body": false,
  "frames": [
    {
      "t": 0,
      "cue": "Postura inicial",
      "right": {
        "position": [0, -1, 0],
        "rotation": [0, 0, 0],
        "fingers": {
          "thumb": [0, 0, 0],
          "index": [0, 0, 0],
          "middle": [0, 0, 0],
          "ring": [0, 0, 0],
          "pinky": [0, 0, 0]
        },
        "spread": { "thumb": 15, "index": 5, "middle": 0, "ring": -5, "pinky": -10 },
        "thumbOpposition": 0
      },
      "left": null
    },
    {
      "t": 1,
      "cue": "Mantén la postura",
      "right": {
        "position": [0, -1, 0],
        "rotation": [0, 0, 0],
        "fingers": {
          "thumb": [0, 0, 0],
          "index": [0, 0, 0],
          "middle": [0, 0, 0],
          "ring": [0, 0, 0],
          "pinky": [0, 0, 0]
        },
        "spread": { "thumb": 15, "index": 5, "middle": 0, "ring": -5, "pinky": -10 },
        "thumbOpposition": 0
      },
      "left": null
    }
  ]
}
```

## Importación, almacenamiento y publicación

- Importa un único objeto JSON, de hasta 512 KB. El taller valida los tipos, los límites, las manos y los tiempos antes de cargarlo.
- Los fotogramas deben tener tiempos únicos y estar ordenados; el primero es `0` y el último `1`. El taller conserva ambos extremos y permite eliminar las posturas intermedias.
- Guardar requiere una sesión activa. Si el servidor o la sesión falla, se muestra el error y se conserva la edición en la página. Descarga el JSON antes de recargar.
- El borrado de un borrador pide confirmación y afecta solo a la cuenta actual.
- Importar o cargar una animación del diccionario crea una copia editable con estado `draft`. El editor no convierte un borrador en contenido validado.
- Para añadir contenido al catálogo general, una persona responsable debe revisar la seña y agregar su objeto al archivo de biblioteca que consume el visor. Conservar los mismos identificadores evita romper las referencias de las lecciones.

## Contrato del visor

```js
await window.SenixSigns.ready;
const sign = window.SenixSigns.getSign('A');
const check = window.SenixSigns.validateSign(sign);
if (check.valid) {
  const viewer = await window.SenixSigns.mount(element, { sign, autoplay: false });
  viewer.setSpeed(0.5);
  viewer.play();
  // viewer.pause();
  // viewer.setProgress(0.5); // instante del ciclo, de 0 a 1
  // viewer.setPose(sign.frames[0]);
  // viewer.setSign(otroObjeto, { autoplay: false });
  // viewer.dispose(); // al retirar el componente
}
```

Los textos se muestran como texto; nunca contienen HTML ejecutable. JSON almacena datos y no admite scripts, funciones ni referencias remotas.
