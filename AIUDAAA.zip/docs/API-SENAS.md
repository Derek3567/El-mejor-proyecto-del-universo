# Formato de señas procedurales SENIX

El motor recibe datos JSON completos e interpola las poses en orden temporal. No interpreta código, expresiones ni URLs como comandos. Todos los ángulos se expresan en **grados**; una flexión positiva cierra el dedo hacia la palma y el frente de la mano (+Z en su sistema local). La posición usa las unidades del modelo. `right` y `left` son las manos anatómicas de la persona que hace la seña.

Las animaciones personales se guardan como `draft` (pendientes de validación LSM). El estado `reviewed` del formato se reserva para contenido revisado fuera del editor y no puede obtenerse mediante esta API. Tener una animación completa no demuestra que la seña, la variante regional o los componentes faciales sean lingüísticamente correctos.

## Contrato JSON

| Campo | Tipo y límites |
|---|---|
| `id` | Identificador textual, 1–100 caracteres; distinto del ID numérico de almacenamiento |
| `label` | Nombre visible, 1–120 caracteres |
| `kind` | `letter`, `number`, `word` o `phrase` |
| `description` | Texto, hasta 3000 caracteres |
| `instructions` | Lista de hasta 30 textos, cada uno de 1–500 caracteres |
| `status` | `draft` o `reviewed`; los guardados personales se convierten a `draft` |
| `duration` | Segundos, número finito de 0.5 a 60 |
| `body` | Booleano para mostrar una referencia corporal |
| `aliases` | Opcional: hasta 40 nombres alternativos de 1–120 caracteres |
| `sourceUrls` | Opcional: hasta 20 enlaces HTTPS de hasta 2048 caracteres, sin credenciales |
| `frames` | Entre 2 y 120 poses completas |

Cada pose lleva `t`, `cue`, `right` y `left`. `t` va de 0 a 1 y debe aumentar estrictamente: la primera pose empieza en 0 y la última termina en 1. `cue` es una indicación de hasta 500 caracteres. Una mano puede ser `null`, pero al menos una debe estar presente en cada pose.

Cada mano contiene todos estos campos:

```json
{
  "position": [0, -1, 0],
  "rotation": [0, 0, 0],
  "fingers": {
    "thumb": [0, 0, 0],
    "index": [0, 0, 0],
    "middle": [0, 0, 0],
    "ring": [0, 0, 0],
    "pinky": [0, 0, 0]
  },
  "spread": {"thumb": 35, "index": 6, "middle": 0, "ring": -5, "pinky": -10},
  "thumbOpposition": 0
}
```

`position` admite −8…8 por eje; `rotation` admite −360…360. Las ternas de los dedos son MCP/PIP/DIP; en el pulgar son CMC/MCP/IP. Cada flexión admite −30…160. `spread` admite −90…90 por dedo y `thumbOpposition` −90…180. El motor combina la oposición del pulgar con su flexión y separación. Son parámetros de una representación pedagógica simplificada, no una simulación biomecánica.

Los objetos rechazan propiedades desconocidas, números no finitos, tipos incorrectos y campos ausentes. El JSON total admite hasta 512 KiB. No deben omitirse valores para heredar otra pose: todas las poses son completas y pueden editarse de forma independiente. Los textos se conservan como texto; toda interfaz debe insertarlos con `textContent` o escaparlos con `htmlspecialchars`, nunca con `innerHTML`.

## Utilidades JavaScript

`assets/js/sign-schema.js` no tiene dependencias. Expone `window.SenixSignSchema` en el navegador y `module.exports` en Node:

```js
const { validateSign, normalizeKey, handPose } = SenixSignSchema;
const example = {
  id: 'ejemplo-abierta-cerrada', label: 'Ejemplo de edición', kind: 'word',
  description: 'Movimiento técnico; pendiente de validación LSM.',
  instructions: ['Observa la palma.', 'Cierra los dedos lentamente.'],
  status: 'draft', duration: 3, body: false,
  frames: [
    { t: 0, cue: 'Mano abierta', right: handPose('open'), left: null },
    { t: 1, cue: 'Mano cerrada', right: handPose('fist'), left: null }
  ]
};
const result = validateSign(example); // {valid: true, errors: []}
```

`validateSign` devuelve errores de campos en español y no modifica el objeto. `handPose` crea manos independientes para `open`, `fist`, `point` o `pinch`; ninguna de estas plantillas certifica una seña LSM. `normalizeKey` elimina acentos y puntuación, transforma espacios a guiones y preserva la diferencia entre N y Ñ.

## API personal autenticada

Ruta: `signs-api.php`, en el mismo origen del sitio. Utiliza la sesión existente y el token `$_SESSION['learn_csrf']` que prepara la página del editor. Las respuestas son JSON, sin caché y con `X-Content-Type-Options: nosniff`. No se permite escribir mediante GET. Los POST usan `application/x-www-form-urlencoded`.

**Listar:** `GET signs-api.php`

```json
{"success":true,"signs":[{"id":42,"label":"Mi seña","payload":{},"updated_at":"2026-10-22 20:00:00"}]}
```

`payload` contiene el objeto completo del formato anterior (el objeto vacío solo abrevia este ejemplo). `updated_at` es la fecha/hora que devuelve MySQL. Solo se entregan las señas de la cuenta que tiene la sesión activa.

**Crear:** `POST signs-api.php` con `action=save`, `csrf_token` y `payload=JSON.stringify(sign)`.

**Actualizar:** los mismos campos y `id`, el identificador **numérico** devuelto por el guardado o listado. El `id` textual dentro del JSON identifica el contenido y no concede acceso a otra fila.

```js
const body = new URLSearchParams({
  action: 'save', csrf_token: pageCsrfToken, payload: JSON.stringify(example)
});
const response = await fetch('signs-api.php', { method: 'POST', body, credentials: 'same-origin' });
const saved = await response.json(); // {success: true, id: 42}
```

**Eliminar:** `POST signs-api.php` con `action=delete`, `csrf_token` e `id`. Devuelve `{"success":true}`. Un ID ajeno o inexistente devuelve el mismo 404.

| Estado HTTP | Motivo |
|---|---|
| 400 | Acción, identificador o campos de solicitud incorrectos |
| 401 | Sesión ausente o caducada |
| 404 | Seña inexistente en la colección propia |
| 405 | Método distinto de GET o POST |
| 409 | Límite de 100 señas personales alcanzado |
| 413 | JSON de más de 512 KiB |
| 419 | Token CSRF ausente, inválido o caducado |
| 422 | JSON mal formado o valores fuera del contrato |
| 503 | Almacenamiento temporalmente no disponible |

Los errores devuelven `success:false` y `error` legible; la validación de campos puede añadir `errors:string[]`. Las consultas usan parámetros PDO y la propiedad de cada fila se comprueba con el ID de usuario de la sesión. La creación de filas se serializa por usuario dentro de una transacción para que las solicitudes simultáneas respeten el límite de 100.

## Almacenamiento y operación

La API crea de forma aditiva la tabla InnoDB `custom_sign_animations` si no existe: `id`, `user_id`, `label`, `payload_json` (`MEDIUMTEXT`) y `updated_at`, con índice por usuario y clave foránea hacia `users(id)`. No altera las tablas de lecciones ni el diccionario. El usuario de MySQL necesita permiso `CREATE` para la instalación inicial; si no lo tiene, el administrador debe ejecutar la sentencia `CREATE TABLE` de `signs-api.php` una vez. Las señas personales se incluyen en futuras copias de la base de datos y pueden exportarse individualmente como JSON desde el editor.

Pruebas del contrato: `node --test tests/sign-schema.test.cjs`. Si PHP está disponible, la prueba compara también el validador del servidor con muestras válidas e inválidas. La disponibilidad real de MySQL, la sesión, el CSRF y la persistencia deben verificarse en el entorno desplegado con una cuenta de prueba.
