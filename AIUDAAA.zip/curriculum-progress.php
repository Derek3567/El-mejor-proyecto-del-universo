<?php
require_once __DIR__ . '/includes/learning-tools.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
learn_ensure_tables();
learn_verify_csrf();

function curriculum_reply(array $data, int $status=200): never {
    http_response_code($status);
    echo json_encode($data, JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
    exit;
}
function curriculum_attempt(string $token, int $userId, string $key): ?array {
    $state=$_SESSION['curriculum_attempts'][$token]??null;
    if(!is_array($state)||(int)($state['user_id']??0)!==$userId||($state['lesson_key']??'')!==$key||time()-(int)($state['started_at']??0)>7200)return null;
    return $state;
}

$action=(string)($_POST['action']??'');
$key=(string)($_POST['lesson_key']??'');
$timezone=learn_timezone((string)($_POST['timezone']??''));
if($action==='test-complete'&&APP_ENV!=='development')curriculum_reply(['success'=>false,'message'=>'La herramienta de prueba solo está disponible en desarrollo.'],403);
if(!in_array($action,['start','item','answer','complete','test-complete','summary'],true))curriculum_reply(['success'=>false,'message'=>'Acción no válida.'],400);
if($action==='summary'){
    $q=$pdo->prepare('SELECT lesson_key,quiz_score,quiz_total,elapsed_seconds,camera_seen_samples,camera_samples,completed_at_utc FROM user_curriculum_attempts WHERE user_id=? ORDER BY completed_at_utc DESC,id DESC');$q->execute([$learnUserId]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);$summary=[];
    foreach($rows as $row){$lesson=(string)$row['lesson_key'];$score=(int)$row['quiz_score'];$total=(int)$row['quiz_total'];$percent=$total>0?(int)round($score/$total*100):0;if(!isset($summary[$lesson]))$summary[$lesson]=['attempts'=>0,'best_score'=>$percent,'last_score'=>$percent,'last_time'=>(int)$row['elapsed_seconds'],'last_camera_rate'=>(int)$row['camera_samples']>0?(int)round((int)$row['camera_seen_samples']/(int)$row['camera_samples']*100):0,'last_completed'=>$row['completed_at_utc']];$summary[$lesson]['attempts']++;$summary[$lesson]['best_score']=max($summary[$lesson]['best_score'],$percent);}
    $trend=[];foreach(array_slice($rows,0,12) as $row){$total=(int)$row['quiz_total'];$trend[]=['lesson_key'=>(string)$row['lesson_key'],'score'=>(int)$row['quiz_score'],'total'=>$total,'percent'=>$total>0?(int)round((int)$row['quiz_score']/$total*100):0,'time'=>(int)$row['elapsed_seconds'],'completed_at'=>(string)$row['completed_at_utc']];}
    curriculum_reply(['success'=>true,'lessons'=>$summary,'attempts'=>$trend]);
}
if(!learn_curriculum_can_start($learnUserId,$key))curriculum_reply(['success'=>false,'message'=>'Completa las lecciones anteriores para desbloquear esta.'],403);

if($action==='start'){
    $entry=learn_curriculum_lesson($key);
    if(!$entry)curriculum_reply(['success'=>false,'message'=>'No encontramos esta lección.'],404);
    $quiz=learn_curriculum_build_quiz($key);
    if(!$quiz['client']||!$quiz['stored'])curriculum_reply(['success'=>false,'message'=>'Esta lección aún no tiene preguntas suficientes para el repaso.'],422);
    $attempt=bin2hex(random_bytes(24));
    $_SESSION['curriculum_attempts'][$attempt]=[
        'user_id'=>$learnUserId,'lesson_key'=>$key,'started_at'=>time(),'timezone'=>$timezone,
        'item_count'=>count($entry['lesson']['items']),'next_item'=>0,'last_item_at'=>time(),
        'camera_samples'=>0,'camera_seen_samples'=>0,'camera_visible_ms'=>0,'practice_ms'=>0,
        'quiz'=>$quiz['stored']
    ];
    if(count($_SESSION['curriculum_attempts'])>8)$_SESSION['curriculum_attempts']=array_slice($_SESSION['curriculum_attempts'],-8,null,true);
    curriculum_reply(['success'=>true,'attempt'=>$attempt,'quiz'=>$quiz['client'],'item_count'=>count($entry['lesson']['items']),'lesson_title'=>$entry['lesson']['title'],'validated'=>!empty($entry['section_data']['validated'])]);
}

$attempt=(string)($_POST['attempt']??'');
$state=curriculum_attempt($attempt,$learnUserId,$key);
if(!$state)curriculum_reply(['success'=>false,'message'=>'La práctica expiró. Inicia la lección nuevamente.'],400);

if($action==='item'){
    $index=filter_var($_POST['item_index']??null,FILTER_VALIDATE_INT);
    $visibleMs=max(0,min(10000,(int)($_POST['visible_ms']??0)));
    $samples=max(0,min(5000,(int)($_POST['samples']??0)));
    $seenSamples=max(0,min($samples,(int)($_POST['seen_samples']??0)));
    $next=(int)$state['next_item'];
    if($index===false||$index===null||$index!==$next||(int)$state['item_count']<=$next)curriculum_reply(['success'=>false,'message'=>'El orden de la práctica no coincide. Recarga la lección.'],409);
    if($visibleMs<2500||$samples<8||$seenSamples<1)curriculum_reply(['success'=>false,'message'=>'Mantén la mano visible mientras MediaPipe registra el objetivo.'],422);
    $now=time();$segmentMs=max(0,min(120000,($now-(int)$state['last_item_at'])*1000));
    if($segmentMs<1500)curriculum_reply(['success'=>false,'message'=>'Practica el objetivo durante unos segundos antes de continuar.'],422);
    $state['next_item']=$next+1;$state['last_item_at']=$now;
    $state['camera_samples']+=(int)$samples;$state['camera_seen_samples']+=(int)$seenSamples;
    $state['camera_visible_ms']+=(int)$visibleMs;$state['practice_ms']+=(int)$segmentMs;
    $_SESSION['curriculum_attempts'][$attempt]=$state;
    curriculum_reply(['success'=>true,'items_completed'=>$state['next_item'],'item_count'=>$state['item_count'],'elapsed_ms'=>$segmentMs]);
}

if($action==='answer'){
    if((int)$state['next_item']!==(int)$state['item_count'])curriculum_reply(['success'=>false,'message'=>'Completa primero los objetivos de práctica.'],409);
    $questionId=(string)($_POST['question_id']??'');$choiceId=(string)($_POST['choice_id']??'');
    $question=$state['quiz'][$questionId]??null;
    if(!is_array($question)||!isset($question['choices'][$choiceId]))curriculum_reply(['success'=>false,'message'=>'La opción no pertenece a este cuestionario.'],400);
    if(!empty($question['answered']))curriculum_reply(['success'=>false,'message'=>'Esta pregunta ya fue respondida.'],409);
    $correct=hash_equals((string)$question['correct'],$choiceId);
    $question['answered']=true;$question['selected']=$choiceId;$question['is_correct']=$correct;
    $state['quiz'][$questionId]=$question;$_SESSION['curriculum_attempts'][$attempt]=$state;
    $score=0;$answered=0;foreach($state['quiz'] as $saved){if(!empty($saved['answered'])){$answered++;if(!empty($saved['is_correct']))$score++;}}
    curriculum_reply(['success'=>true,'correct'=>$correct,'correct_answer'=>$question['choices'][$question['correct']],'score'=>$score,'answered'=>$answered,'total'=>count($state['quiz']),'explanation'=>(string)($question['explanation']??''),'source'=>(string)($question['source']??''),'source_url'=>(string)($question['source_url']??'')]);
}

if($action==='test-complete'){
    try{$result=learn_save_curriculum_completion($learnUserId,$key,$timezone,0,0);$refresh=['stats'=>null,'achievements'=>[],'leaderboard'=>[],'xp_required'=>100];global $userModel,$achievementModel;$refresh['stats']=$userModel->getStats($learnUserId);$refresh['achievements']=$achievementModel->getUserAchievements($learnUserId);$refresh['leaderboard']=$userModel->getLeaderboard(5,0);if($refresh['stats'])$refresh['xp_required']=xp_for_level((int)$refresh['stats']['level']);curriculum_reply(['success'=>true,'first'=>$result['first'],'xp'=>$result['xp'],'completed'=>learn_curriculum_completed($learnUserId)]+$refresh);}catch(DomainException $e){curriculum_reply(['success'=>false,'message'=>$e->getMessage()],403);}catch(Throwable $e){error_log('[Senix curriculum test] '.$e->getMessage());curriculum_reply(['success'=>false,'message'=>'No se pudo guardar el progreso.'],500);}
}

if((int)$state['next_item']!==(int)$state['item_count'])curriculum_reply(['success'=>false,'message'=>'Completa todos los objetivos con la cámara antes de cerrar la lección.'],409);
$quizScore=0;$quizTotal=count($state['quiz']);$answered=0;
foreach($state['quiz'] as $question){if(empty($question['answered']))curriculum_reply(['success'=>false,'message'=>'Responde todas las preguntas del repaso.'],409);$answered++;if(!empty($question['is_correct']))$quizScore++;}
if($answered!==$quizTotal)curriculum_reply(['success'=>false,'message'=>'El repaso está incompleto.'],409);
$elapsed=max(0,min(7200,time()-(int)$state['started_at']));
$visibleMs=max(0,min($elapsed*1000,(int)$state['camera_visible_ms']));
$samples=max(0,min(500000,(int)$state['camera_samples']));
$seenSamples=max(0,min($samples,(int)$state['camera_seen_samples']));
$cameraFps=$visibleMs>0?round($seenSamples/($visibleMs/1000),1):0.0;
$accuracy=$quizTotal>0?round($quizScore/$quizTotal*100,1):0.0;
try{
    $result=learn_save_curriculum_completion($learnUserId,$key,$timezone,$quizScore,$quizTotal);
    $save=$pdo->prepare('INSERT INTO user_curriculum_results(user_id,lesson_key,quiz_score,quiz_total,time_spent,completed_at_utc) VALUES(?,?,?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE quiz_score=VALUES(quiz_score),quiz_total=VALUES(quiz_total),time_spent=VALUES(time_spent),completed_at_utc=VALUES(completed_at_utc)');
    $save->execute([$learnUserId,$key,$quizScore,$quizTotal,$elapsed]);
    $history=$pdo->prepare('INSERT INTO user_curriculum_attempts(user_id,lesson_key,elapsed_seconds,camera_samples,camera_seen_samples,camera_visible_ms,camera_fps,items_completed,quiz_score,quiz_total,xp_awarded,completed_at_utc) VALUES(?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())');
    $history->execute([$learnUserId,$key,$elapsed,$samples,$seenSamples,$visibleMs,$cameraFps,(int)$state['item_count'],$quizScore,$quizTotal,(int)$result['xp']]);
    global $achievementModel; try { if (isset($achievementModel)) $achievementModel->checkAll($learnUserId); } catch (Throwable $e) { error_log('[Senix curriculum achievement check] '.$e->getMessage()); }
    $bestQuery=$pdo->prepare('SELECT MAX(CASE WHEN quiz_total>0 THEN ROUND(quiz_score*100/quiz_total) ELSE 0 END) best_score,COUNT(*) attempt_count FROM user_curriculum_attempts WHERE user_id=? AND lesson_key=?');$bestQuery->execute([$learnUserId,$key]);$bestStats=$bestQuery->fetch(PDO::FETCH_ASSOC)?:['best_score'=>0,'attempt_count'=>1];

    $refresh=['stats'=>null,'achievements'=>[],'leaderboard'=>[],'xp_required'=>100];
    global $userModel,$achievementModel;
    $refresh['stats']=$userModel->getStats($learnUserId);$refresh['achievements']=$achievementModel->getUserAchievements($learnUserId);$refresh['leaderboard']=$userModel->getLeaderboard(5,0);
    if($refresh['stats'])$refresh['xp_required']=xp_for_level((int)$refresh['stats']['level']);
    $review=[];foreach($state['quiz'] as $question){$review[]=['prompt'=>(string)($question['prompt']??''),'selected'=>(string)($question['choices'][$question['selected']??'']??''),'correct'=>(string)($question['choices'][$question['correct']]??''),'is_correct'=>!empty($question['is_correct']),'explanation'=>(string)($question['explanation']??''),'source'=>(string)($question['source']??'')];}
    $_SESSION['curriculum_completed_attempts'][$attempt]=['user_id'=>$learnUserId,'lesson_key'=>$key,'completed_at'=>time(),'elapsed_seconds'=>$elapsed,'quiz_score'=>$quizScore,'quiz_total'=>$quizTotal,'quiz_accuracy'=>$accuracy,'camera'=>['samples'=>$samples,'seen_samples'=>$seenSamples,'visible_ms'=>$visibleMs,'fps'=>$cameraFps],'items_completed'=>(int)$state['item_count'],'review'=>$review];
    if(count($_SESSION['curriculum_completed_attempts'])>8)$_SESSION['curriculum_completed_attempts']=array_slice($_SESSION['curriculum_completed_attempts'],-8,null,true);
    unset($_SESSION['curriculum_attempts'][$attempt]);
    curriculum_reply(['success'=>true,'first'=>$result['first'],'xp'=>$result['xp'],'xp_base'=>$result['xp_base'],'quiz_bonus'=>$result['quiz_bonus'],'quiz_score'=>$quizScore,'quiz_total'=>$quizTotal,'quiz_accuracy'=>$accuracy,'time_spent'=>$elapsed,'camera'=>['samples'=>$samples,'seen_samples'=>$seenSamples,'visible_ms'=>$visibleMs,'fps'=>$cameraFps],'items_completed'=>(int)$state['item_count'],'best_score'=>(int)($bestStats['best_score']??0),'attempt_count'=>(int)($bestStats['attempt_count']??1),'completed'=>learn_curriculum_completed($learnUserId)]+$refresh);
}catch(DomainException $e){curriculum_reply(['success'=>false,'message'=>$e->getMessage()],403);}catch(Throwable $e){error_log('[Senix curriculum completion] '.$e->getMessage());curriculum_reply(['success'=>false,'message'=>'No se pudo guardar el progreso. Inténtalo de nuevo.'],500);}