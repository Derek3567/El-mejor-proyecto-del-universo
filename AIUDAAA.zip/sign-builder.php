<?php
require_once __DIR__ . '/includes/learning-tools.php';
learn_header('Taller de señas 3D', 'Construye una postura, añade movimientos y guarda tu propia seña.', ['sign-viewer.css', 'sign-editor.css?v=20261023-2']);
?>
<div id="sign-editor" class="se-editor" data-csrf="<?= learn_h($_SESSION['learn_csrf']) ?>">
  <div class="se-intro"><a href="<?= learn_h(APP_URL) ?>/menu.php#dictionary">← Volver al diccionario</a><span class="se-badge">LSM · borrador personal</span></div>
  <p class="se-notice">Las animaciones de este taller están <strong>pendientes de validación en LSM</strong>. Revisa la forma, la orientación, el movimiento y la expresión con una persona competente en LSM antes de usarlas como referencia.</p>
  <div class="se-toolbar" aria-label="Acciones de la seña">
    <button type="button" class="se-btn se-primary" id="se-save" disabled>Guardar en mi cuenta</button>
    <button type="button" class="se-btn" id="se-export" disabled>Descargar JSON</button>
    <button type="button" class="se-btn" id="se-import-button" disabled>Importar JSON</button>
    <button type="button" class="se-btn" id="se-new" disabled>Nueva seña</button>
    <input type="file" id="se-import" accept=".json,application/json" hidden>
    <span id="se-save-state">Iniciando taller…</span>
  </div>
  <div id="se-status" class="se-status" role="status" aria-live="polite">Cargando las herramientas 3D…</div>
  <noscript><p class="se-notice">Activa JavaScript para construir y visualizar las señas.</p></noscript>

  <div class="se-layout">
    <section class="se-preview-column" aria-labelledby="se-preview-title">
      <div class="se-card se-preview-card">
        <div class="se-section-heading"><div><span class="se-kicker">VISTA PREVIA</span><h2 id="se-preview-title">Mira cada detalle</h2></div><span class="se-dot-label">3D</span></div>
        <div id="se-viewer" class="se-viewer" aria-label="Vista previa de la seña en tres dimensiones"></div>
        <div class="se-preview-actions"><button type="button" id="se-play" class="se-btn se-primary" disabled>▶ Ver animación</button><button type="button" id="se-stop" class="se-btn" disabled>Volver a la postura</button><label class="se-inline-label" for="se-speed">Velocidad<select id="se-speed"><option value="0.5">Lenta · 0.5×</option><option value="1">Normal · 1×</option><option value="0.25">Muy lenta · 0.25×</option></select></label></div>
        <p class="se-help">Edita una postura para verla al instante. Usa los controles del visor para cambiar el punto de vista. Derecha e izquierda corresponden a quien hace la seña.</p>
        <label class="se-check"><input type="checkbox" id="se-body"> Mostrar referencia de cabeza y torso</label>
      </div>
      <section class="se-card" aria-labelledby="se-library-title">
        <span class="se-kicker">PUNTO DE PARTIDA</span><h2 id="se-library-title">Partir de una seña</h2>
        <p class="se-help">Carga una animación del diccionario y ajusta una copia en tu espacio.</p>
        <label for="se-library">Seña del diccionario</label><div class="se-input-action"><select id="se-library"><option value="">Selecciona una seña…</option></select><button type="button" class="se-btn" id="se-load-base" disabled>Cargar</button></div>
        <div class="se-section-heading se-drafts-heading"><h3>Mis borradores</h3><button type="button" class="se-text-btn" id="se-refresh">Actualizar</button></div>
        <p id="se-drafts-status" class="se-help">Cargando tus borradores…</p><ul id="se-drafts" class="se-draft-list" aria-label="Borradores guardados en tu cuenta"></ul>
      </section>
    </section>

    <div class="se-controls-column">
      <section class="se-card" aria-labelledby="se-details-title">
        <span class="se-kicker">01 · DESCRIBE</span><h2 id="se-details-title">Tu seña</h2>
        <div class="se-two-col"><label>Nombre<input id="se-label" type="text" maxlength="120" value="Mi nueva seña" autocomplete="off"></label><label>Tipo<select id="se-kind"><option value="word">Palabra</option><option value="letter">Letra</option><option value="number">Número</option><option value="phrase">Frase</option></select></label></div>
        <label>Descripción<textarea id="se-description" rows="2" maxlength="3000" placeholder="Qué significa y en qué contexto se usa"></textarea></label>
        <label>Instrucciones <span class="se-label-note">Una por línea</span><textarea id="se-instructions" rows="3" maxlength="6000" placeholder="1. Coloca la mano frente al pecho.&#10;2. Realiza el movimiento despacio."></textarea></label>
      </section>

      <section class="se-card" aria-labelledby="se-timeline-title">
        <div class="se-section-heading"><div><span class="se-kicker">02 · ORGANIZA EL MOVIMIENTO</span><h2 id="se-timeline-title">Posturas clave</h2></div><label class="se-duration">Duración (s)<input id="se-duration" type="number" min="0.5" max="60" step="0.5" value="4"></label></div>
        <p class="se-help">El sistema une las posturas suavemente. Para una seña estática, conserva la misma postura al inicio y al final.</p>
        <div id="se-frames" class="se-frames" role="group" aria-label="Seleccionar postura clave"></div>
        <div class="se-row"><button type="button" class="se-btn" id="se-add">+ Postura abierta</button><button type="button" class="se-btn" id="se-duplicate">Duplicar postura</button><button type="button" class="se-text-btn se-danger" id="se-remove-frame">Eliminar</button></div>
        <div class="se-two-col se-frame-fields"><label>Momento (%)<input id="se-time" type="number" min="0" max="100" step="0.1" aria-describedby="se-time-help"></label><label>Indicación para esta postura<input id="se-cue" type="text" maxlength="500" placeholder="Por ejemplo: gira la palma hacia delante"></label></div>
        <p class="se-help" id="se-time-help">Inicio y final permanecen en 0 % y 100 %. Añade posturas intermedias para crear movimiento.</p>
      </section>

      <section class="se-card" aria-labelledby="se-hand-title">
        <span class="se-kicker">03 · DA FORMA A LA MANO</span><h2 id="se-hand-title">Dedos y articulaciones</h2>
        <div class="se-hand-visibility" role="group" aria-label="Manos visibles en esta postura"><label class="se-check"><input type="checkbox" id="se-right-visible" checked> Mano derecha</label><label class="se-check"><input type="checkbox" id="se-left-visible"> Mano izquierda</label></div>
        <label>Mano que estás editando<select id="se-hand"><option value="right">Derecha</option><option value="left">Izquierda</option></select></label>
        <p id="se-hidden-hand" class="se-notice" hidden>Esta mano está oculta en la postura. Activa su casilla para editarla.</p>
        <fieldset id="se-hand-controls" class="se-fieldset">
          <legend class="se-sr-only">Ajustes de la mano seleccionada</legend>
          <div class="se-presets" role="group" aria-label="Formas iniciales"><button type="button" class="se-preset" data-preset="open">Abierta</button><button type="button" class="se-preset" data-preset="fist">Puño</button><button type="button" class="se-preset" data-preset="point">Índice</button><button type="button" class="se-preset" data-preset="pinch">Pinza</button></div>
          <label>Dedo<select id="se-finger"><option value="thumb">Pulgar</option><option value="index" selected>Índice</option><option value="middle">Medio</option><option value="ring">Anular</option><option value="pinky">Meñique</option></select></label>
          <p class="se-help">0° estira la articulación. Aumenta el ángulo para doblarla hacia la palma.</p>
          <div id="se-joint-controls" class="se-slider-stack"></div>
          <div id="se-spread-control"></div><div id="se-opposition-control"></div>
          <details class="se-transform" open><summary>Ubicación y orientación de la mano</summary><p class="se-help">X: lado a lado · Y: altura · Z: hacia delante y atrás. Los ángulos se miden en grados.</p><div id="se-position-controls" class="se-slider-stack"></div><div id="se-rotation-controls" class="se-slider-stack"></div></details>
        </fieldset>
      </section>
      <details class="se-card se-json"><summary>Ver el objeto JSON</summary><p class="se-help">Este archivo describe toda la animación y se puede importar de nuevo en el taller. <a href="docs/SIGN-JSON.md" target="_blank" rel="noopener">Consultar el formato</a>.</p><label for="se-json-output" class="se-sr-only">JSON generado de la seña</label><textarea id="se-json-output" readonly spellcheck="false" rows="12"></textarea><button type="button" id="se-copy" class="se-btn">Copiar JSON</button></details>
    </div>
  </div>
  <dialog id="se-confirm" class="se-dialog"><form method="dialog"><h2 id="se-confirm-title">Confirmar acción</h2><p id="se-confirm-message"></p><div class="se-row"><button class="se-btn" value="cancel" autofocus>Cancelar</button><button id="se-confirm-accept" class="se-btn se-primary" value="accept">Continuar</button></div></form></dialog>
</div>
<script src="<?= learn_h(asset('vendor/three.min.js')) ?>"></script>
<script src="<?= learn_h(asset('js/sign-schema.js')) ?>"></script>
<script src="<?= learn_h(asset('js/sign-viewer.js')) ?>"></script>
<script src="<?= learn_h(asset('js/sign-editor.js')) ?>"></script>
<?php learn_footer(); ?>
