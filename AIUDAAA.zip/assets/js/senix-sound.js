/* Sonidos locales, activados únicamente después de una acción del usuario. */
(() => {
  'use strict';
  const base = '/assets/audio/';
  const names = ['click', 'transition', 'success', 'error', 'ambient'];
  const clips = Object.fromEntries(names.map(name => {
    const clip = new Audio(base + name + '.wav' + (name === 'click' ? '?v=20261026-2' : ''));
    clip.preload = name === 'click' ? 'auto' : 'none';
    clip.volume = name === 'ambient' ? 0.09 : 0.28;
    if (name === 'ambient') clip.loop = true;
    return [name, clip];
  }));
  // El clic se precarga y decodifica una vez para reproducirse sin demora.
  let clickContext = null;
  let clickBuffer = null;
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (AudioContextClass) {
    try {
      clickContext = new AudioContextClass();
      fetch(base + 'click.wav?v=20261026-2')
        .then(response => response.ok ? response.arrayBuffer() : Promise.reject(new Error('Audio no disponible')))
        .then(data => clickContext.decodeAudioData(data))
        .then(buffer => { clickBuffer = buffer; })
        .catch(() => {});
    } catch (_) { clickContext = null; }
  }
  let enabled = false;
  try { enabled = localStorage.getItem('senix-sound') === 'on'; } catch (_) {}

  function play(name) {
    if (!enabled || !clips[name]) return;
    if (name === 'click' && clickContext && clickBuffer) {
      if (clickContext.state !== 'running') clickContext.resume().catch(() => {});
      const source = clickContext.createBufferSource();
      const volume = clickContext.createGain();
      source.buffer = clickBuffer;
      volume.gain.value = 0.32;
      source.connect(volume).connect(clickContext.destination);
      source.start();
      return;
    }
    const clip = clips[name];
    if (name !== 'ambient') clip.currentTime = 0;
    clip.play().catch(() => {});
  }
  function stopAmbient() { clips.ambient.pause(); clips.ambient.currentTime = 0; }
  function setEnabled(value) {
    enabled = Boolean(value);
    try { localStorage.setItem('senix-sound', enabled ? 'on' : 'off'); } catch (_) {}
    control.setAttribute('aria-pressed', String(enabled));
    control.textContent = enabled ? '♫ Sonido' : '♪ Sin sonido';
    control.title = enabled ? 'Desactivar sonidos' : 'Activar sonidos';
    if (enabled) { play('click'); play('ambient'); } else stopAmbient();
  }
  const control = document.createElement('button');
  control.type = 'button';
  control.className = 'senix-sound-control';
  control.setAttribute('aria-label', 'Activar o desactivar sonidos');
  control.setAttribute('aria-pressed', String(enabled));
  control.textContent = enabled ? '♫ Sonido' : '♪ Sin sonido';
  const target = document.querySelector('.senix-nav-actions,.top-actions,.learn-tool-top');
  if (target) target.insertBefore(control, target.firstChild);
  else document.body.append(control);
  control.addEventListener('click', () => setEnabled(!enabled));
  document.addEventListener('pointerdown', () => {
    if (enabled && clips.ambient.paused) play('ambient');
  }, { once: true, passive: true });
  document.addEventListener('click', event => {
    if (event.target.closest('.senix-sound-control')) return;
    const actionable = event.target.closest('button,a');
    if (!actionable || actionable.disabled) return;
    play(actionable.matches('a[href^="#"],.sx-nav-item,[data-go]') ? 'transition' : 'click');
  }, { passive: true });
  window.addEventListener('senix:sound', event => play(event.detail?.name || 'success'));
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) clips.ambient.pause();
    else if (enabled) play('ambient');
  });
  window.SenixSound = { play, setEnabled };
})();
