/* SENIX · Procedural sign authoring. All content is rendered as text. */
(function () {
  'use strict';
  const root = document.getElementById('sign-editor');
  if (!root) return;
  const $ = (id) => document.getElementById('se-' + id);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const fingerNames = { thumb: 'Pulgar', index: 'Índice', middle: 'Medio', ring: 'Anular', pinky: 'Meñique' };
  const maxFrames = 120;
  let engine, sign, library, viewer, frameIndex = 0, savedId = null, dirty = false, redraw = 0, saving = false;
  let handSide = 'right', finger = 'index', draftRows = [], selectedFile = null;
  const newId = () => 'draft-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  function hand(preset, side) {
    const result = clone(engine.handPose(preset || 'open'));
    result.position = side === 'left' ? [-1.5, -1, 0] : [0, -1, 0];
    return result;
  }
  function newSign() {
    const pose = hand('open', 'right');
    return { id: newId(), label: 'Mi nueva seña', kind: 'word', aliases: [], description: '', instructions: [], status: 'draft', duration: 4, body: false,
      frames: [{ t: 0, cue: 'Postura inicial', right: clone(pose), left: null }, { t: 1, cue: 'Postura final', right: clone(pose), left: null }] };
  }
  function status(message, kind) {
    $('status').textContent = message;
    $('status').dataset.kind = kind || 'success';
  }
  function markDirty() {
    dirty = true;
    $('save-state').textContent = 'Cambios sin guardar';
  }
  function json() { $('json-output').value = JSON.stringify(sign, null, 2); }
  function currentFrame() { return sign.frames[frameIndex]; }
  function currentHand() { return currentFrame()[handSide]; }
  function refreshPreview() {
    json();
    if (!viewer || redraw) return;
    redraw = requestAnimationFrame(function () {
      redraw = 0;
      try {
        const preview = clone(sign);
        if (!preview.label.trim()) preview.label = 'Seña sin nombre';
        if (!engine.validateSign(preview).valid) return;
        viewer.pause();
        viewer.setSign(preview, { autoplay: false });
        viewer.setProgress(currentFrame().t);
      } catch (error) { status('No se pudo actualizar la vista 3D: ' + error.message, 'error'); }
    });
  }
  function changed() { markDirty(); refreshPreview(); }
  function validated() {
    const result = engine.validateSign(sign);
    if (!result.valid) {
      status('Revisa estos datos antes de continuar:\n' + result.errors.slice(0, 8).join('\n'), 'error');
      $('status').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      return false;
    }
    return true;
  }
  async function confirmAction(title, message, accept) {
    const dialog = $('confirm');
    $('confirm-title').textContent = title;
    $('confirm-message').textContent = message;
    $('confirm-accept').textContent = accept || 'Continuar';
    if (typeof dialog.showModal !== 'function') return window.confirm(message);
    return new Promise(function (resolve) {
      dialog.returnValue = 'cancel';
      dialog.addEventListener('close', function () { resolve(dialog.returnValue === 'accept'); }, { once: true });
      dialog.showModal();
    });
  }
  async function canReplace() {
    if (saving) { status('Espera a que termine el guardado antes de cambiar de seña.', 'loading'); return false; }
    const accepted = !dirty || await confirmAction('Tienes cambios sin guardar', 'Si cargas otra seña, se perderán los cambios actuales. Puedes cancelar y guardarlos o descargar el JSON primero.', 'Descartar y continuar');
    return accepted && !saving;
  }
  function replaceSign(value, id) {
    sign = clone(value);
    sign.status = 'draft';
    if (!id) sign.id = newId();
    savedId = id || null;
    frameIndex = 0;
    handSide = currentFrame().right ? 'right' : 'left';
    finger = 'index';
    dirty = !id;
    $('save-state').textContent = id ? 'Borrador guardado en tu cuenta' : 'Copia nueva · pendiente de guardar';
    render();
  }
  function renderFrames() {
    const list = $('frames');
    list.replaceChildren();
    sign.frames.forEach(function (frame, index) {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'se-frame';
      button.setAttribute('aria-pressed', String(index === frameIndex));
      button.setAttribute('aria-label', 'Postura ' + (index + 1) + ', ' + Math.round(frame.t * 1000) / 10 + ' por ciento. ' + (frame.cue || ''));
      const title = document.createElement('strong'); title.textContent = index === 0 ? 'Inicio' : index === sign.frames.length - 1 ? 'Final' : 'Postura ' + (index + 1);
      const time = document.createElement('span'); time.textContent = Math.round(frame.t * 1000) / 10 + ' %';
      button.append(title, time);
      button.addEventListener('click', function () { frameIndex = index; renderFrameEditor(); refreshPreview(); });
      list.append(button);
    });
    const endpoint = frameIndex === 0 || frameIndex === sign.frames.length - 1;
    $('time').value = Math.round(currentFrame().t * 1000) / 10;
    $('time').disabled = endpoint;
    $('remove-frame').disabled = endpoint;
    $('add').disabled = $('duplicate').disabled = sign.frames.length >= maxFrames;
    $('cue').value = currentFrame().cue || '';
  }
  function slider(parentId, id, title, unit, min, max, step, value, update) {
    const parent = $(parentId);
    const row = document.createElement('div'); row.className = 'se-slider';
    const label = document.createElement('label'); label.htmlFor = 'se-range-' + id;
    label.textContent = title;
    const suffix = document.createElement('small'); suffix.textContent = unit; label.append(suffix);
    const range = document.createElement('input'); range.type = 'range'; range.id = 'se-range-' + id;
    const number = document.createElement('input'); number.type = 'number'; number.id = 'se-number-' + id;
    number.setAttribute('aria-label', title + (unit ? ', ' + unit : '') + ', valor exacto');
    [range, number].forEach(function (input) { input.min = min; input.max = max; input.step = step; input.value = value; });
    range.addEventListener('input', function () { number.value = range.value; update(Number(range.value)); changed(); });
    number.addEventListener('input', function () {
      if (number.value === '' || !Number.isFinite(number.valueAsNumber)) return;
      const value = number.valueAsNumber;
      if (value < min || value > max) { number.setCustomValidity('Introduce un valor entre ' + min + ' y ' + max + '.'); return; }
      number.setCustomValidity(''); range.value = value; update(value); changed();
    });
    number.addEventListener('change', function () {
      if (!number.checkValidity() || number.value === '') { number.reportValidity(); number.value = range.value; number.setCustomValidity(''); }
    });
    row.append(label, range, number); parent.append(row);
  }
  function renderHandEditor() {
    $('hand').value = handSide;
    $('finger').value = finger;
    $('right-visible').checked = !!currentFrame().right;
    $('left-visible').checked = !!currentFrame().left;
    $('hand-controls').disabled = !currentHand();
    $('hidden-hand').hidden = !!currentHand();
    ['joint-controls', 'spread-control', 'opposition-control', 'position-controls', 'rotation-controls'].forEach((id) => $(id).replaceChildren());
    const pose = currentHand();
    if (!pose) return;
    const joints = finger === 'thumb' ? ['Base · CMC', 'Centro · MCP', 'Punta · IP'] : ['Nudillo · MCP', 'Centro · PIP', 'Punta · DIP'];
    joints.forEach(function (name, index) {
      slider('joint-controls', 'joint-' + index, name, 'grados', -30, 160, 1, pose.fingers[finger][index], function (value) { currentHand().fingers[finger][index] = value; });
    });
    slider('spread-control', 'spread', 'Separación del ' + fingerNames[finger].toLowerCase(), 'grados', -90, 90, 1, pose.spread[finger], function (value) { currentHand().spread[finger] = value; });
    if (finger === 'thumb') slider('opposition-control', 'opposition', 'Oposición del pulgar', 'grados', -90, 180, 1, pose.thumbOpposition, function (value) { currentHand().thumbOpposition = value; });
    ['X · Lateral', 'Y · Altura', 'Z · Profundidad'].forEach(function (axis, index) {
      slider('position-controls', 'position-' + index, axis, 'posición', -8, 8, 0.05, pose.position[index], function (value) { currentHand().position[index] = value; });
    });
    ['X · Inclinar', 'Y · Girar', 'Z · Ladear'].forEach(function (axis, index) {
      slider('rotation-controls', 'rotation-' + index, axis, 'muñeca · grados', -360, 360, 1, pose.rotation[index], function (value) { currentHand().rotation[index] = value; });
    });
  }
  function renderFrameEditor() { renderFrames(); renderHandEditor(); }
  function render() {
    $('label').value = sign.label;
    $('kind').value = sign.kind;
    $('description').value = sign.description || '';
    $('instructions').value = (sign.instructions || []).join('\n');
    $('duration').value = sign.duration;
    $('body').checked = !!sign.body;
    renderFrameEditor(); refreshPreview();
  }
  function insertFrame(duplicate) {
    if (sign.frames.length >= maxFrames) { status('Puedes usar hasta ' + maxFrames + ' posturas por seña.', 'error'); return; }
    let left = frameIndex < sign.frames.length - 1 ? frameIndex : frameIndex - 1;
    if (sign.frames[left + 1].t - sign.frames[left].t < 0.002) {
      let best = 0;
      sign.frames.slice(0, -1).forEach(function (frame, i) { if (sign.frames[i + 1].t - frame.t > best) { best = sign.frames[i + 1].t - frame.t; left = i; } });
    }
    const t = (sign.frames[left].t + sign.frames[left + 1].t) / 2;
    const frame = duplicate ? clone(currentFrame()) : { right: hand('open', 'right'), left: null, cue: '' };
    frame.t = t;
    if (duplicate) frame.cue = currentFrame().cue || '';
    sign.frames.splice(left + 1, 0, frame);
    frameIndex = left + 1;
    renderFrameEditor(); changed();
    status(duplicate ? 'Postura duplicada. Ajusta el momento y cambia la forma o la ubicación de la mano.' : 'Postura añadida. Ajusta sus dedos, ubicación y orientación.');
  }
  async function api(body) {
    const options = { credentials: 'same-origin', headers: { Accept: 'application/json' } };
    if (body) {
      options.method = 'POST';
      options.body = new URLSearchParams(Object.assign({ csrf_token: root.dataset.csrf }, body));
    }
    const response = await fetch('signs-api.php', options);
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new Error('No se pudo acceder a tu cuenta. Recarga la página e inicia sesión de nuevo; descarga el JSON primero para conservar los cambios.');
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error((data.error || data.message || 'El servidor no pudo completar la operación.') + (Array.isArray(data.errors) ? '\n' + data.errors.slice(0, 6).join('\n') : ''));
    return data;
  }
  async function refreshDrafts() {
    $('refresh').disabled = true;
    $('drafts-status').textContent = 'Cargando tus borradores…';
    try {
      const data = await api();
      draftRows = Array.isArray(data.signs) ? data.signs : [];
      $('drafts').replaceChildren();
      $('drafts-status').textContent = draftRows.length ? 'Privados de tu cuenta · pendientes de validación' : 'Aún no tienes borradores. Guarda tu primera seña cuando esté lista.';
      draftRows.forEach(function (draft) {
        const item = document.createElement('li');
        const title = document.createElement('span'); title.className = 'se-draft-title'; title.textContent = draft.label || 'Sin nombre';
        const detail = document.createElement('small'); detail.textContent = String(draft.id) === String(savedId) ? 'Abierto en el taller' : 'Borrador personal'; title.append(detail);
        const load = document.createElement('button'); load.type = 'button'; load.className = 'se-btn'; load.textContent = 'Abrir'; load.setAttribute('aria-label', 'Abrir ' + (draft.label || 'borrador'));
        load.addEventListener('click', async function () {
          try {
            const value = typeof draft.payload === 'string' ? JSON.parse(draft.payload) : draft.payload;
            const result = engine.validateSign(value);
            if (!result.valid) throw new Error(result.errors.slice(0, 4).join(' '));
            if (!(await canReplace())) return;
            replaceSign(value, draft.id);
            status('Borrador «' + sign.label + '» cargado.');
          } catch (error) { status('No se pudo cargar este borrador: ' + error.message, 'error'); }
        });
        const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'se-text-btn se-danger'; remove.textContent = 'Borrar'; remove.setAttribute('aria-label', 'Borrar ' + (draft.label || 'borrador'));
        remove.addEventListener('click', async function () {
          if (saving) { status('Espera a que termine el guardado antes de borrar un borrador.', 'loading'); return; }
          if (!(await confirmAction('Borrar borrador', 'Se eliminará «' + (draft.label || 'Sin nombre') + '» de tu cuenta. Esta acción no se puede deshacer. Una copia abierta en el taller se conserva hasta que salgas.', 'Borrar borrador'))) return;
          if (saving) return;
          remove.disabled = true;
          try {
            await api({ action: 'delete', id: draft.id });
            if (String(savedId) === String(draft.id)) { savedId = null; sign.id = newId(); markDirty(); json(); }
            status('Borrador eliminado de tu cuenta.');
            await refreshDrafts();
          } catch (error) { remove.disabled = false; status(error.message, 'error'); }
        });
        item.append(title, load, remove); $('drafts').append(item);
      });
    } catch (error) { $('drafts-status').textContent = error.message; }
    finally { $('refresh').disabled = false; }
  }
  async function save() {
    if (saving || !validated()) return;
    saving = true; $('save').disabled = true;
    const savedDocument = sign;
    const snapshot = JSON.stringify(sign);
    const body = { action: 'save', payload: snapshot };
    if (savedId) body.id = savedId;
    status('Guardando el borrador en tu cuenta…', 'loading');
    try {
      const data = await api(body);
      if (sign === savedDocument) {
        savedId = data.id;
        dirty = snapshot !== JSON.stringify(sign);
        $('save-state').textContent = dirty ? 'Hay cambios nuevos sin guardar' : 'Guardado en tu cuenta';
      }
      status('Borrador guardado. Sigue pendiente de validación en LSM.');
      if (typeof engine.registerSign === 'function') engine.registerSign(JSON.parse(snapshot));
      await refreshDrafts();
    } catch (error) { status(error.message, 'error'); }
    finally { saving = false; $('save').disabled = false; }
  }
  async function importFile(file) {
    if (!file) return;
    if (file.size > 512 * 1024) { status('El archivo supera el límite de 512 KB. Importa un único objeto JSON de seña.', 'error'); return; }
    try {
      const value = JSON.parse(await file.text());
      const result = engine.validateSign(value);
      if (!result.valid) { status('El JSON contiene errores:\n' + result.errors.slice(0, 8).join('\n'), 'error'); return; }
      if (!(await canReplace())) return;
      replaceSign(value, null);
      status('JSON importado como una copia nueva. Revisa la animación y guárdala en tu cuenta.');
    } catch (error) { status('No se pudo importar el archivo JSON: ' + error.message, 'error'); }
  }
  function exportFile() {
    if (!validated()) return;
    const blob = new Blob([JSON.stringify(sign, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = 'senix-' + (sign.label.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase() || 'sena') + '.json';
    document.body.append(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    status('JSON preparado para descargar. Guarda también en tu cuenta si quieres abrirlo desde otro dispositivo.');
  }
  function play() {
    if (!viewer || !validated()) return;
    if (redraw) { cancelAnimationFrame(redraw); redraw = 0; }
    viewer.setSign(clone(sign), { autoplay: false });
    if (typeof viewer.setSpeed === 'function') viewer.setSpeed(Number($('speed').value));
    else { const slow = clone(sign); slow.duration = sign.duration / Number($('speed').value); viewer.setSign(slow, { autoplay: false }); }
    viewer.setProgress(0); viewer.play();
  }
  function bind() {
    $('label').addEventListener('input', function () { sign.label = this.value; changed(); });
    $('kind').addEventListener('change', function () { sign.kind = this.value; changed(); });
    $('description').addEventListener('input', function () { sign.description = this.value; changed(); });
    $('instructions').addEventListener('input', function () { sign.instructions = this.value.split('\n').map((line) => line.trim()).filter(Boolean); changed(); });
    $('duration').addEventListener('change', function () {
      if (!this.checkValidity() || !this.value) { this.reportValidity(); this.value = sign.duration; return; }
      sign.duration = Number(this.value); changed();
    });
    $('body').addEventListener('change', function () { sign.body = this.checked; changed(); });
    $('cue').addEventListener('input', function () { currentFrame().cue = this.value; changed(); });
    $('time').addEventListener('change', function () {
      const value = Number(this.value) / 100;
      if (!this.value || !Number.isFinite(value) || value <= 0 || value >= 1 || sign.frames.some((frame, i) => i !== frameIndex && Math.abs(frame.t - value) < 0.00001)) {
        status('Cada postura intermedia necesita un momento distinto, mayor que 0 % y menor que 100 %.', 'error'); renderFrames(); return;
      }
      const frame = currentFrame(); frame.t = value;
      sign.frames.sort((a, b) => a.t - b.t); frameIndex = sign.frames.indexOf(frame);
      renderFrames(); changed();
    });
    $('add').addEventListener('click', () => insertFrame(false));
    $('duplicate').addEventListener('click', () => insertFrame(true));
    $('remove-frame').addEventListener('click', function () {
      if (frameIndex === 0 || frameIndex === sign.frames.length - 1) return;
      sign.frames.splice(frameIndex, 1); frameIndex = Math.max(0, frameIndex - 1); renderFrameEditor(); changed();
    });
    ['right', 'left'].forEach(function (side) {
      $(side + '-visible').addEventListener('change', function () {
        const other = side === 'right' ? 'left' : 'right';
        if (!this.checked && !currentFrame()[other]) { this.checked = true; status('Mantén al menos una mano visible en cada postura.', 'error'); return; }
        currentFrame()[side] = this.checked ? hand('open', side) : null;
        if (this.checked) handSide = side;
        else if (handSide === side) handSide = other;
        renderHandEditor(); changed();
      });
    });
    $('hand').addEventListener('change', function () { handSide = this.value; renderHandEditor(); });
    $('finger').addEventListener('change', function () { finger = this.value; renderHandEditor(); });
    root.querySelectorAll('[data-preset]').forEach(function (button) {
      button.addEventListener('click', function () {
        const pose = currentHand(); if (!pose) return;
        const preset = hand(button.dataset.preset, handSide);
        preset.position = clone(pose.position); preset.rotation = clone(pose.rotation);
        currentFrame()[handSide] = preset; renderHandEditor(); changed();
      });
    });
    $('save').addEventListener('click', save);
    $('export').addEventListener('click', exportFile);
    $('import-button').addEventListener('click', () => $('import').click());
    $('import').addEventListener('change', async function () { selectedFile = this.files[0]; this.value = ''; await importFile(selectedFile); selectedFile = null; });
    $('new').addEventListener('click', async function () { if (await canReplace()) { replaceSign(newSign(), null); status('Nueva seña creada. Ajusta la postura inicial y la final para empezar.'); } });
    $('refresh').addEventListener('click', refreshDrafts);
    $('library').addEventListener('change', function () { $('load-base').disabled = !this.value; });
    $('load-base').addEventListener('click', async function () {
      const base = engine.getSign($('library').value);
      if (!base) { status('No se encontró la animación seleccionada.', 'error'); return; }
      if (!(await canReplace())) return;
      replaceSign(base, null); status('Copia de «' + sign.label + '» lista para editar. Se guardará como un borrador personal.');
    });
    $('play').addEventListener('click', play);
    $('stop').addEventListener('click', refreshPreview);
    $('speed').addEventListener('change', function () { if (viewer && typeof viewer.setSpeed === 'function') viewer.setSpeed(Number(this.value)); });
    $('copy').addEventListener('click', async function () {
      try { await navigator.clipboard.writeText(JSON.stringify(sign, null, 2)); status('JSON copiado al portapapeles.'); }
      catch (_) { $('json-output').focus(); $('json-output').select(); status('Seleccionamos el JSON. Usa Ctrl+C o la opción Copiar de tu dispositivo.'); }
    });
    window.addEventListener('beforeunload', function (event) { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
    window.addEventListener('pagehide', function (event) { if (!event.persisted && viewer) viewer.dispose(); });
  }
  async function start() {
    try {
      engine = window.SenixSigns;
      if (!engine) throw new Error('No se pudieron cargar las herramientas. Comprueba tu conexión y recarga la página.');
      library = await engine.ready;
      sign = newSign();
      bind(); render();
      (library.signs || []).slice().sort((a, b) => a.label.localeCompare(b.label, 'es')).forEach(function (value) {
        const option = document.createElement('option'); option.value = value.id; option.textContent = value.label; $('library').append(option);
      });
      ['save', 'export', 'import-button', 'new'].forEach((id) => $(id).disabled = false);
      $('save-state').textContent = 'Nueva seña · pendiente de guardar';
      status('Elige una seña del diccionario o empieza con la mano abierta. Cada cambio se ve al instante.');
      try {
        viewer = await engine.mount($('viewer'), { sign: clone(sign), autoplay: false });
        if (typeof viewer.setSpeed === 'function') viewer.setSpeed(Number($('speed').value));
        $('play').disabled = $('stop').disabled = false;
        refreshPreview();
      } catch (error) {
        $('viewer').textContent = 'No se pudo iniciar la vista 3D. ' + error.message;
        status('La vista 3D no está disponible. Puedes editar, importar y guardar los datos; prueba un navegador con WebGL para ver la animación.', 'error');
      }
      await refreshDrafts();
    } catch (error) { status(error.message, 'error'); $('save-state').textContent = 'No se pudo iniciar el taller'; $('drafts-status').textContent = 'Recarga la página para volver a intentarlo.'; }
  }
  start();
}());
