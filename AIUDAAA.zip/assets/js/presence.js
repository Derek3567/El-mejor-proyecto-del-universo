(() => {
  'use strict';
  const control = document.getElementById('presence-control');
  const toggle = document.getElementById('presence-toggle');
  const menu = document.getElementById('presence-menu');
  const label = document.getElementById('presence-label');
  const feedback = document.getElementById('presence-feedback');
  const course = window.SENIX_COURSE;
  if (!control || !toggle || !menu || !label || !course) return;

  const labels = { online: 'USUARIO EN LÍNEA', offline: 'USUARIO DESCONECTADO', private: 'USUARIO PRIVADO' };
  const endpoint = course.community || 'community-api.php';
  let latestRequest = 0;
  let sessionExpired = false;
  let lastActivity = Date.now();
  let heartbeatPending = false;

  function display(mode) {
    if (!Object.hasOwn(labels, mode)) return;
    label.textContent = labels[mode];
    control.dataset.presence = mode;
    menu.querySelectorAll('[data-presence]').forEach(option => {
      option.setAttribute('aria-checked', String(option.dataset.presence === mode));
    });
  }

  function setOpen(open) {
    menu.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    if (open) menu.querySelector('[aria-checked="true"]')?.focus();
  }

  async function request(mode) {
    const id = ++latestRequest;
    const changing = mode !== undefined;
    const options = { credentials: 'same-origin', cache: 'no-store' };
    let url = endpoint + (endpoint.includes('?') ? '&' : '?') + 'action=presence';
    if (changing) {
      options.method = 'POST';
      options.headers = { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' };
      options.body = new URLSearchParams({ action: 'presence', mode, csrf_token: course.csrf });
      url = endpoint;
    }
    options.headers = { ...(options.headers || {}), Accept: 'application/json' };
    const response = await fetch(url, options);
    const raw = await response.text();
    let data = null;
    try { data = raw.trim() ? JSON.parse(raw) : null; } catch (_) {}
    const redirectedToLogin = response.redirected && /\/login\.php(?:$|[?#])/i.test(response.url || '');
    if (response.status === 401 || response.status === 419 || redirectedToLogin) {
      sessionExpired = true;
      throw new Error('Tu sesión expiró. Recarga la página para continuar.');
    }
    if (!data || typeof data !== 'object') {
      throw new Error('No pudimos actualizar tu estado. Se reintentará automáticamente.');
    }
    if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo guardar tu estado.');
    if (id === latestRequest) display(data.mode);
  }

  toggle.addEventListener('click', () => setOpen(menu.hidden));
  menu.querySelectorAll('[data-presence]').forEach(option => {
    option.addEventListener('click', async () => {
      option.disabled = true;
      feedback.textContent = '';
      try {
        await request(option.dataset.presence);
        setOpen(false);
        toggle.focus();
      } catch (error) {
        feedback.textContent = error.message;
      } finally {
        option.disabled = false;
      }
    });
  });
  document.addEventListener('click', event => {
    if (!control.contains(event.target)) setOpen(false);
  });
  document.addEventListener('keydown', event => {
    lastActivity = Date.now();
    if (event.key === 'Escape' && !menu.hidden) {
      setOpen(false);
      toggle.focus();
    }
  });

  const heartbeat = () => {
    if (document.hidden || sessionExpired || heartbeatPending || Date.now() - lastActivity > 120000) return;
    heartbeatPending = true;
    request().then(() => { feedback.textContent = ''; }).catch(error => {
      feedback.textContent = sessionExpired ? error.message : '';
    }).finally(() => { heartbeatPending = false; });
  };
  for (const event of ['pointerdown', 'scroll']) {
    document.addEventListener(event, () => { lastActivity = Date.now(); }, { passive: true });
  }
  heartbeat();
  window.setInterval(heartbeat, 60000);
  document.addEventListener('visibilitychange', heartbeat);
})();
