(()=>{'use strict';
const cfg=window.SENIX_COURSE||{},$=s=>document.querySelector(s),start=$('#video-call-start'),leave=$('#video-call-leave'),report=$('#video-call-report'),status=$('#video-call-status'),localVideo=$('#video-local'),remoteVideo=$('#video-remote'),empty=$('#video-match-empty');
if(!start||!cfg.videoEndpoint)return;
let stream=null,peer=null,roomId=0,pollTimer=0,pollBusy=false,waitingSince=0,lastSignal=0,pendingIce=[],closed=false;
const cameraSelect=window.SenixCameraDevices?.attach(start,()=>stream,changeCamera);
async function changeCamera(){
 if(!stream)return;
 try{
  const next=await navigator.mediaDevices.getUserMedia({audio:false,video:window.SenixCameraDevices.constraints(cameraSelect)});
  const newTrack=next.getVideoTracks()[0],old=stream;
  const sender=peer?.getSenders().find(item=>item.track?.kind==='video');
  if(sender)await sender.replaceTrack(newTrack);
  stream=next;if(localVideo){localVideo.srcObject=next;await localVideo.play().catch(()=>{})}
  old.getTracks().forEach(track=>track.stop());
  window.SenixCameraDevices.sync(next);setStatus('Cámara cambiada. La llamada continúa sin audio.');
 }catch(error){setStatus('No se pudo cambiar de cámara: '+(error.message||'dispositivo no disponible'));}
}
function setStatus(message){if(status)status.textContent=message}
function send(action,extra={},method='POST'){const url=cfg.videoEndpoint+(method==='GET'?'?'+new URLSearchParams({action,...extra}):'');const options={method,credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}};if(method==='POST'){options.headers['Content-Type']='application/x-www-form-urlencoded;charset=UTF-8';options.body=new URLSearchParams({action,csrf_token:cfg.csrf||'',...extra})}return fetch(url,options).then(async response=>{let data;try{data=await response.json()}catch{throw Error('La sesión expiró. Recarga la página.')}if(!response.ok||data.error)throw Error(data.error||'No se pudo conectar.');return data})}
function stopTracks(){if(stream){stream.getTracks().forEach(track=>track.stop());stream=null}if(localVideo)localVideo.srcObject=null}
function destroyPeer(){if(peer){peer.ontrack=null;peer.onicecandidate=null;peer.onconnectionstatechange=null;peer.close();peer=null}if(remoteVideo)remoteVideo.srcObject=null;pendingIce=[]}
function endLocal(message){clearInterval(pollTimer);pollTimer=0;closed=true;destroyPeer();stopTracks();roomId=0;lastSignal=0;waitingSince=0;if(start){start.disabled=false;start.textContent='Buscar encuentro visual'}if(leave)leave.disabled=true;if(report)report.disabled=true;if(empty)empty.hidden=false;setStatus(message||'La llamada terminó. Tu cámara está apagada.')}
async function stopCall(message='La llamada terminó. Tu cámara está apagada.',notify=true){const id=roomId;clearInterval(pollTimer);pollTimer=0;closed=true;if(notify){try{await send('leave',{room_id:String(id)})}catch{}}endLocal(message)}
async function initPeer(data){
 if(peer||closed)return;roomId=Number(data.room_id)||0;if(!roomId)return;
 peer=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
 stream.getVideoTracks().forEach(track=>peer.addTrack(track,stream));
 peer.ontrack=event=>{if(remoteVideo){remoteVideo.srcObject=event.streams[0];remoteVideo.muted=true;remoteVideo.play().catch(()=>{})}if(empty)empty.hidden=true;setStatus('Conectada con '+(data.peer?.name||'otra persona')+'. Comunicación visual, sin audio.')};
 peer.onicecandidate=event=>{if(event.candidate)send('signal',{room_id:String(roomId),signal_type:'ice',payload:JSON.stringify(event.candidate.toJSON())}).catch(()=>{})};
 peer.onconnectionstatechange=()=>{if(!peer)return;if(peer.connectionState==='connected'){setStatus('Conectada con '+(data.peer?.name||'otra persona')+'. Comunicación visual, sin audio.');if(empty)empty.hidden=true}else if(peer.connectionState==='failed')setStatus('La red no permitió conectar. Termina e inténtalo otra vez.');else if(peer.connectionState==='disconnected')setStatus('La conexión visual se interrumpió; intentando restablecerla…')};
 if(data.initiator){const offer=await peer.createOffer();await peer.setLocalDescription(offer);await send('signal',{room_id:String(roomId),signal_type:'offer',payload:JSON.stringify(peer.localDescription.toJSON())})}
}
async function handleSignal(signal){
 if(!peer||!signal||!signal.type)return;
 if(signal.type==='offer'){await peer.setRemoteDescription(new RTCSessionDescription(signal.payload));while(pendingIce.length)try{await peer.addIceCandidate(new RTCIceCandidate(pendingIce.shift()))}catch{}const answer=await peer.createAnswer();await peer.setLocalDescription(answer);await send('signal',{room_id:String(roomId),signal_type:'answer',payload:JSON.stringify(peer.localDescription.toJSON())})}
 else if(signal.type==='answer'&&peer.signalingState!=='stable'){await peer.setRemoteDescription(new RTCSessionDescription(signal.payload));while(pendingIce.length)try{await peer.addIceCandidate(new RTCIceCandidate(pendingIce.shift()))}catch{}}
 else if(signal.type==='ice'){if(peer.remoteDescription)await peer.addIceCandidate(new RTCIceCandidate(signal.payload));else pendingIce.push(signal.payload)}
}
async function poll(){
 if(pollBusy||closed)return;pollBusy=true;try{
  const values={};if(roomId)values.room_id=String(roomId);if(lastSignal)values.after_id=String(lastSignal);
  const data=await send('poll',values,'GET');
  if(data.status==='ended'){endLocal('La otra persona terminó la llamada. Tu cámara está apagada.');return}
  if(data.status==='active'&&Number(data.room_id)){await initPeer(data);for(const signal of(data.signals||[])){lastSignal=Math.max(lastSignal,Number(signal.id)||0);await handleSignal(signal)}}
  else if(!data.waiting&&!roomId){endLocal('No hay una búsqueda activa. Pulsa el botón para buscar otra persona.');return}
  else if(waitingSince&&Date.now()-waitingSince>180000){await send('leave',{});endLocal('No encontramos a alguien disponible en tres minutos. Puedes buscar de nuevo.');return}
 }catch(error){setStatus(error.message)}finally{pollBusy=false}
}
async function begin(){
 if(!navigator.mediaDevices?.getUserMedia){setStatus('Este navegador no permite cámara en esta página. Abre SENIX con HTTPS.');return}
 start.disabled=true;setStatus('Pidiendo permiso para usar solo la cámara…');
 try{closed=false;stream=await navigator.mediaDevices.getUserMedia({video:window.SenixCameraDevices?.constraints(cameraSelect)||{facingMode:'user'},audio:false});if(localVideo){localVideo.srcObject=stream;localVideo.play().catch(()=>{})}window.SenixCameraDevices?.sync(stream);if(empty)empty.hidden=true;setStatus('Buscando a otra persona que también quiera practicar…');const data=await send('queue');if(data.matched){await initPeer(data)}else{waitingSince=Date.now()}leave.disabled=false;report.disabled=false;start.textContent='Esperando…';clearInterval(pollTimer);pollTimer=setInterval(poll,1800);await poll()}
 catch(error){stopTracks();if(empty)empty.hidden=false;start.disabled=false;setStatus(error.name==='NotAllowedError'?'No se concedió permiso de cámara. Puedes cambiarlo desde la configuración del navegador.':error.message)}
}
start.addEventListener('click',begin);leave.addEventListener('click',()=>stopCall());report.addEventListener('click',async()=>{if(!roomId)return;report.disabled=true;setStatus('Bloqueando y enviando el reporte…');try{await send('report',{room_id:String(roomId),reason:'Reporte enviado desde una videollamada aleatoria'});endLocal('La persona quedó bloqueada y el reporte fue recibido.')}catch(error){report.disabled=false;setStatus(error.message)}});
window.addEventListener('pagehide',()=>{clearInterval(pollTimer);if(roomId||waitingSince){try{const body=new URLSearchParams({action:'leave',csrf_token:cfg.csrf||'',room_id:String(roomId||0)});if(navigator.sendBeacon)navigator.sendBeacon(cfg.videoEndpoint,body);else fetch(cfg.videoEndpoint,{method:'POST',body,keepalive:true,credentials:'same-origin'})}catch{}}destroyPeer();stopTracks()});
})();
