/* SENIX procedural hand viewer. Three.js r160; all pose angles are degrees. */
(() => {
  'use strict';
  const scriptURL = document.currentScript.src;
  const libraryURL = new URL('../data/signs-lsm.json?v=20261022-1', scriptURL);
  const apiURL = new URL('../../signs-api.php', scriptURL);
  const schema = window.SenixSignSchema;
  const fingers = ['thumb', 'index', 'middle', 'ring', 'pinky'];
  const labels = ['Pulgar', 'Índice', 'Medio', 'Anular', 'Meñique'];
  const colors = [0xe69a62, 0xdf727a, 0xc5a44e, 0x62a88f, 0x7d9fd0];
  const RAD = Math.PI / 180;
  const lookup = new Map();
  let personalPromise;
  const clone = value => JSON.parse(JSON.stringify(value));
  function registerSign(sign) {
    const check = schema.validateSign(sign);
    if (!check.valid) throw new Error(check.errors.join(' '));
    [sign.id, sign.label, ...(sign.aliases || [])].forEach(key => lookup.set(schema.normalizeKey(key), sign));
    return sign;
  }
  const ready = fetch(libraryURL, {cache: 'no-cache'}).then(response => {
    if (!response.ok) throw new Error('No se pudo cargar la biblioteca de señas.');
    return response.json();
  }).then(library => {
    if (!Array.isArray(library.signs)) throw new Error('La biblioteca de señas no es válida.');
    library.signs.forEach(registerSign);
    return library;
  });
  ready.catch(() => {}); // Each consumer reports the error in its own view.
  function getSign(value) { return lookup.get(schema.normalizeKey(String(value))) || null; }
  async function loadPersonal(force = false) {
    if (personalPromise && !force) return personalPromise;
    personalPromise = ready.then(async () => {
      const response = await fetch(apiURL, {credentials: 'same-origin', cache: 'no-store', headers: {Accept:'application/json'}});
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.error || 'No se pudieron cargar tus señas.');
      return (data.signs || []).map(row => {
        // Personal drafts are namespaced: they never replace a curriculum entry.
        const sign = clone(row.payload);
        sign.id = 'personal-' + row.id;
        lookup.set(sign.id, sign);
        return sign;
      });
    });
    return personalPromise;
  }
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function button(text, title) {
    const node = el('button', 'sign-button', text);
    node.type = 'button';
    if (title) node.setAttribute('aria-label', title);
    return node;
  }
  function roundedBone(THREE, length, radius, material) {
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 5, 12), material);
    mesh.position.y = length / 2;
    return mesh;
  }
  function createHand(THREE, left, resources) {
    const root = new THREE.Group();
    root.scale.set(left ? -.62 : .62, .62, .62);
    const skin = new THREE.MeshStandardMaterial({color: left ? 0x9bd2cd : 0xf2b7a3, roughness: .61, metalness: .02});
    const nail = new THREE.MeshStandardMaterial({color: left ? 0xdcece4 : 0xffe9d6, roughness: .5});
    const shape = new THREE.Shape();
    shape.moveTo(-.51, -.12); shape.bezierCurveTo(-.7,.2,-.95,.7,-.92,1.3);
    shape.bezierCurveTo(-.9,1.72,-.77,1.97,-.61,2.05);
    shape.lineTo(.64,1.89); shape.bezierCurveTo(.87,1.7,.91,.94,.77,.48);
    shape.lineTo(.48,-.12); shape.closePath();
    const palmGeo = new THREE.ExtrudeGeometry(shape, {depth:.32,bevelEnabled:true,bevelSegments:4,steps:1,bevelSize:.13,bevelThickness:.14,curveSegments:12});
    palmGeo.translate(0,0,-.16);
    const palm = new THREE.Mesh(palmGeo,skin); root.add(palm);
    const thenar = new THREE.Mesh(new THREE.SphereGeometry(.42,20,14),skin);
    thenar.scale.set(.8,1.45,.6); thenar.position.set(-.49,.64,.14); root.add(thenar);
    const wrist = roundedBone(THREE,.85,.43,skin); wrist.position.y=-.42; wrist.scale.z=.68; root.add(wrist);
    const specs = {
      thumb:{x:-.82,y:.65,lengths:[.68,.64,.55],radius:.235},
      index:{x:-.59,y:2.03,lengths:[.91,.66,.51],radius:.185},
      middle:{x:-.15,y:2.11,lengths:[1.02,.73,.54],radius:.19},
      ring:{x:.29,y:2.02,lengths:[.94,.68,.50],radius:.175},
      pinky:{x:.68,y:1.85,lengths:[.70,.49,.43],radius:.15}
    };
    const chains = {}, dots = [], colored = [];
    fingers.forEach((name, index) => {
      const spec=specs[name], spread=new THREE.Group();
      spread.position.set(spec.x,spec.y,name==='thumb'?.22:0); root.add(spread);
      const joints=[]; let parent=spread;
      spec.lengths.forEach((length,j) => {
        const pivot=new THREE.Group(); if(j)pivot.position.y=spec.lengths[j-1]; parent.add(pivot);
        const mat=skin.clone(); const segment=roundedBone(THREE,length,spec.radius*(1-j*.12),mat); pivot.add(segment);
        colored.push({material:mat,index});
        const dot=new THREE.Mesh(new THREE.SphereGeometry(spec.radius*.65,10,8),new THREE.MeshBasicMaterial({color:colors[index],depthTest:false}));
        dot.position.z=.24; dot.renderOrder=5; dot.visible=false; pivot.add(dot); dots.push(dot);
        if(j===2){const n=new THREE.Mesh(new THREE.SphereGeometry(.1,12,8),nail);n.scale.set(spec.radius*7,length*3,.23);n.position.set(0,length*.64,-spec.radius*.88);pivot.add(n)}
        joints.push(pivot);parent=pivot;
      });
      chains[name]={spread,joints};
    });
    root.traverse(node=>{if(node.geometry)resources.add(node.geometry);if(node.material)resources.add(node.material)});
    return {root,chains,dots,colored,skin};
  }
  function createBody(THREE, resources) {
    const group=new THREE.Group(),mat=new THREE.MeshStandardMaterial({color:0xbdcfcd,transparent:true,opacity:.25,roughness:1,depthWrite:false});
    function ball(x,y,z,sx,sy,sz){const m=new THREE.Mesh(new THREE.SphereGeometry(1,24,16),mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);group.add(m);return m}
    ball(0,3.7,-.85,.7,.9,.56); ball(0,2.64,-.85,.27,.42,.3); ball(0,.7,-1.15,1.7,1.8,.55);
    ball(-1.62,1.73,-1.12,.45,.7,.42);ball(1.62,1.73,-1.12,.45,.7,.42);
    const faceMat=new THREE.MeshBasicMaterial({color:0x789b96,transparent:true,opacity:.65});
    for(const x of [-.23,.23]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.045,8,8),faceMat);eye.position.set(x,3.9,-.31);group.add(eye)}
    const nose=new THREE.Mesh(new THREE.ConeGeometry(.07,.24,8),faceMat);nose.rotation.x=Math.PI/2;nose.position.set(0,3.65,-.24);group.add(nose);
    group.traverse(node=>{if(node.geometry)resources.add(node.geometry);if(node.material)resources.add(node.material)});
    return group;
  }
  class Viewer {
    constructor(container, options) {
      if (!window.THREE) throw new Error('No se cargó el motor 3D. Recarga la página.');
      this.container=container;this.resources=new Set();this.abort=new AbortController();this.disposed=false;
      this.progress=0;this.speed=1;this.playing=false;this.mirror=false;this.yaw=.10;this.pitch=.07;this.zoom=1;this.endPause=0;
      const T=this.T=window.THREE;
      container.replaceChildren();container.classList.add('sign-viewer');
      this.header=el('div','sign-viewer-heading');this.title=el('strong','','Guía 3D');this.badge=el('span','sign-review-badge','BORRADOR · POR VALIDAR');this.header.append(this.title,this.badge);
      this.stage=el('div','sign-viewport');this.stage.tabIndex=0;this.stage.setAttribute('aria-label','Modelo 3D. Arrastra para girar o usa las vistas y los botones de zoom.');
      const legend=el('div','sign-hand-legend');legend.append(el('span','right-hand','Derecha'),el('span','left-hand','Izquierda'));
      this.stage.append(legend);this.angleHint=el('span','sign-angle-hint','Arrastra para girar');this.stage.append(this.angleHint);
      this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.7));
      this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.setClearColor(0xffffff,0);this.renderer.domElement.setAttribute('aria-hidden','true');this.stage.prepend(this.renderer.domElement);
      this.scene=new T.Scene();this.scene.add(new T.HemisphereLight(0xffffff,0x819c99,2.3));
      const light=new T.DirectionalLight(0xfff4dd,3);light.position.set(-3,6,8);this.scene.add(light);
      const rim=new T.DirectionalLight(0xb0e8ef,2);rim.position.set(4,2,-3);this.scene.add(rim);
      this.rig=new T.Group();this.scene.add(this.rig);
      this.hands={right:createHand(T,false,this.resources),left:createHand(T,true,this.resources)};
      this.rig.add(this.hands.right.root,this.hands.left.root);this.body=createBody(T,this.resources);this.rig.add(this.body);
      this.camera=new T.PerspectiveCamera(35,1,.1,100);this.target=new T.Vector3(0,.4,0);this.baseDistance=8;
      this.cue=el('p','sign-cue');this.cue.setAttribute('aria-live','polite');
      const transport=el('div','sign-transport');this.playButton=button('▶ Reproducir','Reproducir animación');this.prev=button('‹','Fotograma anterior');this.next=button('›','Fotograma siguiente');
      this.slider=el('input','sign-timeline');this.slider.type='range';this.slider.min='0';this.slider.max='1';this.slider.step='.001';this.slider.value='0';this.slider.setAttribute('aria-label','Recorrer el movimiento');
      this.time=el('output','sign-time','0.0 s');transport.append(this.playButton,this.prev,this.slider,this.next,this.time);
      const optionsRow=el('div','sign-options');const speedLabel=el('label','','Velocidad ');this.speedSelect=el('select');this.speedSelect.setAttribute('aria-label','Velocidad de la animación');
      [[.25,'0.25×'],[.5,'0.5×'],[1,'Normal'],[1.5,'1.5×']].forEach(([value,label])=>{const o=el('option','',label);o.value=value;if(value===1)o.selected=true;this.speedSelect.append(o)});speedLabel.append(this.speedSelect);
      const viewLabel=el('label','','Vista ');this.viewSelect=el('select');this.viewSelect.setAttribute('aria-label','Ángulo de vista');[['front','Frente'],['side','Lateral'],['back','Dorso']].forEach(([value,label])=>{const o=el('option','',label);o.value=value;this.viewSelect.append(o)});viewLabel.append(this.viewSelect);
      this.mirrorButton=button('Espejo');this.mirrorButton.setAttribute('aria-pressed','false');this.jointButton=button('Articulaciones');this.jointButton.setAttribute('aria-pressed','false');
      const zin=button('+','Acercar modelo'),zout=button('−','Alejar modelo'),reset=button('↺','Restablecer vista');optionsRow.append(speedLabel,viewLabel,this.mirrorButton,this.jointButton,zout,zin,reset);
      this.description=el('p','sign-description');this.steps=el('ol','sign-instructions');this.modelReading=el('aside','sign-model-reading');this.readingTitle=el('strong','','Lectura aproximada del modelo 3D');this.readingText=el('p','','La animación muestra una configuración generada a partir de sus puntos de control.');this.modelReading.append(this.readingTitle,this.readingText);this.validation=el('p','sign-validation','Guía procedural pendiente de validación en LSM. La expresión facial y corporal también forma parte de la seña.');
      this.sources=el('details','sign-sources');
      container.append(this.header,this.stage,this.cue,transport,optionsRow,this.description,this.steps,this.modelReading,this.validation,this.sources);
      this.on(this.playButton,'click',()=>this.playing?this.pause():this.play());this.on(this.slider,'input',()=>{this.pause();this.setProgress(Number(this.slider.value))});
      this.on(this.prev,'click',()=>this.step(-1));this.on(this.next,'click',()=>this.step(1));this.on(this.speedSelect,'change',()=>this.setSpeed(Number(this.speedSelect.value)));
      this.on(this.viewSelect,'change',()=>{this.yaw={front:0,side:Math.PI/2,back:Math.PI}[this.viewSelect.value];this.pitch=.03;this.updateCamera()});
      this.on(this.mirrorButton,'click',()=>{this.mirror=!this.mirror;this.rig.scale.x=this.mirror?-1:1;this.mirrorButton.setAttribute('aria-pressed',String(this.mirror));this.angleHint.textContent=this.mirror?'Vista en espejo · lados invertidos':'Arrastra para girar';const progress=this.progress;this.fit();this.setProgress(progress)});
      this.on(this.jointButton,'click',()=>{const enabled=this.jointButton.getAttribute('aria-pressed')!=='true';this.jointButton.setAttribute('aria-pressed',String(enabled));Object.values(this.hands).forEach(hand=>{hand.dots.forEach(dot=>dot.visible=enabled);hand.colored.forEach(x=>x.material.color.set(enabled?colors[x.index]:hand.skin.color))})});
      this.on(zin,'click',()=>{this.zoom=Math.min(2.2,this.zoom*1.18);this.updateCamera()});this.on(zout,'click',()=>{this.zoom=Math.max(.6,this.zoom/1.18);this.updateCamera()});this.on(reset,'click',()=>{this.yaw=.1;this.pitch=.07;this.zoom=1;this.viewSelect.value='front';this.updateCamera()});
      let pointer=null;
      this.on(this.stage,'pointerdown',event=>{if(event.button!==0)return;pointer={id:event.pointerId,x:event.clientX,y:event.clientY};this.stage.setPointerCapture(event.pointerId)});
      this.on(this.stage,'pointermove',event=>{if(!pointer||pointer.id!==event.pointerId)return;this.yaw-=(event.clientX-pointer.x)*.009;this.pitch=Math.max(-1,Math.min(1,this.pitch+(event.clientY-pointer.y)*.008));pointer.x=event.clientX;pointer.y=event.clientY;this.updateCamera()});
      this.on(this.stage,'pointerup',()=>pointer=null);this.on(this.stage,'pointercancel',()=>pointer=null);
      this.on(this.stage,'keydown',event=>{if(event.target!==this.stage)return;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){event.preventDefault();this.yaw+=(event.key==='ArrowLeft'?.12:event.key==='ArrowRight'?-.12:0);this.pitch=Math.max(-1,Math.min(1,this.pitch+(event.key==='ArrowUp'?.1:event.key==='ArrowDown'?-.1:0)));this.updateCamera()}});
      this.on(this.renderer.domElement,'webglcontextlost',event=>{event.preventDefault();this.pause();this.cue.textContent='Se perdió la vista 3D. Cierra esta vista y vuelve a abrirla.'});
      this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(this.stage);
      this.setSign(options.sign,{autoplay:options.autoplay!==false});this.resize();this.lastAt=performance.now();this.tick=this.tick.bind(this);this.raf=requestAnimationFrame(this.tick);
    }
    on(target,type,fn){target.addEventListener(type,fn,{signal:this.abort.signal})}
    setSign(sign,options={}){
      if(this.disposed)return;
      const result=schema.validateSign(sign);if(!result.valid)throw new Error(result.errors.join(' '));
      this.sign=clone(sign);this.title.textContent=sign.label;this.description.textContent=sign.description;
      this.steps.replaceChildren(...(sign.instructions||[]).map(text=>el('li','',text)));
      this.sources.replaceChildren(el('summary','','Referencias para contrastar esta guía'));
      this.sources.hidden=!(sign.sourceUrls||[]).length;
      (sign.sourceUrls||[]).forEach((url,index)=>{const link=el('a','',`Referencia ${index+1} · ${new URL(url).hostname}`);link.href=url;link.target='_blank';link.rel='noopener noreferrer';this.sources.append(link)});
      this.badge.textContent=sign.status==='reviewed'?'REFERENCIA REVISADA':'BORRADOR · POR VALIDAR';
      this.validation.hidden=sign.status==='reviewed';this.body.visible=!!sign.body;this.progress=0;this.endPause=0;
      this.fit();this.setProgress(0);
      if(options.autoplay!==false&&!matchMedia('(prefers-reduced-motion: reduce)').matches)this.play();else this.pause();
    }
    applyHand(name,pose){
      const hand=this.hands[name];hand.root.visible=!!pose;if(!pose)return;
      hand.root.position.fromArray(pose.position);hand.root.rotation.set(...pose.rotation.map(n=>n*RAD),'XYZ');
      fingers.forEach(finger=>{
        const chain=hand.chains[finger];chain.spread.rotation.set(0,finger==='thumb'?pose.thumbOpposition*RAD:0,((finger==='thumb'?48:0)+pose.spread[finger])*RAD);
        chain.joints.forEach((joint,index)=>joint.rotation.x=pose.fingers[finger][index]*RAD);
      });
    }
    setPose(frame){if(this.disposed)return;this.applyHand('right',frame.right);this.applyHand('left',frame.left);if(frame.cue)this.cue.textContent=frame.cue;const readings=[];[['right','Mano derecha'],['left','Mano izquierda']].forEach(([side,label])=>{const pose=frame[side];if(!pose)return;const states=fingers.map((finger,index)=>{const joints=pose.fingers[finger]||[],bend=joints.reduce((sum,value)=>sum+Math.max(0,Number(value)||0),0)/Math.max(1,joints.length);return labels[index]+(bend>95?' flexionado':bend>42?' parcialmente flexionado':' extendido')});readings.push(label+': '+states.join(', ')+'.')});this.readingText.textContent=readings.length?readings.join(' '):'No hay mano visible en este fotograma.';this.draw()}
    fit(){
      const T=this.T,box=new T.Box3();
      for(const frame of this.sign.frames){this.applyHand('right',frame.right);this.applyHand('left',frame.left);this.rig.updateMatrixWorld(true);for(const name of ['right','left'])if(frame[name])box.union(new T.Box3().setFromObject(this.hands[name].root))}
      if(this.sign.body)box.union(new T.Box3().setFromObject(this.body));
      this.bounds=box;box.getCenter(this.target);this.resize();
    }
    resize(){
      if(this.disposed)return;const width=this.stage.clientWidth,height=this.stage.clientHeight;if(!width||!height)return;
      this.renderer.setSize(width,height,false);this.camera.aspect=width/height;this.camera.updateProjectionMatrix();
      if(this.bounds){const size=this.bounds.getSize(new this.T.Vector3());const tangent=Math.tan(35*RAD/2);this.baseDistance=Math.max(size.y/(2*tangent),size.x/(2*tangent*this.camera.aspect),2.7)+size.z*.5;this.baseDistance*=1.22}
      this.updateCamera();
    }
    updateCamera(){if(this.disposed)return;const d=this.baseDistance/this.zoom;this.camera.position.set(this.target.x+d*Math.sin(this.yaw)*Math.cos(this.pitch),this.target.y+d*Math.sin(this.pitch),this.target.z+d*Math.cos(this.yaw)*Math.cos(this.pitch));this.camera.lookAt(this.target);this.draw()}
    setProgress(value){
      if(this.disposed||!this.sign)return;this.progress=Math.max(0,Math.min(1,value));
      const frames=this.sign.frames;let index=0;while(index<frames.length-2&&frames[index+1].t<=this.progress)index++;
      const a=frames[index],b=frames[index+1];const raw=Math.max(0,Math.min(1,(this.progress-a.t)/(b.t-a.t))),t=raw*raw*(3-2*raw);
      const lerp=(x,y)=>x+(y-x)*t;
      for(const name of ['right','left']){
        if(!a[name]||!b[name]){this.applyHand(name,this.progress>=b.t?b[name]:a[name]);continue}
        const h1=a[name],h2=b[name],pose={position:h1.position.map((x,i)=>lerp(x,h2.position[i])),rotation:[0,0,0],fingers:{},spread:{},thumbOpposition:lerp(h1.thumbOpposition,h2.thumbOpposition)};
        const q1=new this.T.Quaternion().setFromEuler(new this.T.Euler(...h1.rotation.map(n=>n*RAD),'XYZ'));
        const q2=new this.T.Quaternion().setFromEuler(new this.T.Euler(...h2.rotation.map(n=>n*RAD),'XYZ'));
        const rotation=new this.T.Euler().setFromQuaternion(q1.slerp(q2,t),'XYZ');pose.rotation=[rotation.x/RAD,rotation.y/RAD,rotation.z/RAD];
        fingers.forEach(finger=>{pose.fingers[finger]=h1.fingers[finger].map((x,i)=>lerp(x,h2.fingers[finger][i]));pose.spread[finger]=lerp(h1.spread[finger],h2.spread[finger])});this.applyHand(name,pose);
      }
      const cue=(this.progress===1?frames[frames.length-1]:a).cue||'Observa la posición de los dedos y la orientación de la palma.';
      if(this.cue.textContent!==cue)this.cue.textContent=cue;
      this.slider.value=this.progress;this.time.textContent=(this.progress*this.sign.duration).toFixed(1)+' s';this.draw();
    }
    step(direction){this.pause();const frames=this.sign.frames;let target=direction>0?frames.find(f=>f.t>this.progress+.001):[...frames].reverse().find(f=>f.t<this.progress-.001);this.setProgress(target?target.t:direction>0?1:0)}
    setSpeed(value){this.speed=Math.max(.25,Math.min(2,Number(value)||1));this.speedSelect.value=String(this.speed)}
    play(){if(this.disposed)return;if(this.progress===1)this.setProgress(0);this.playing=true;this.lastAt=performance.now();this.playButton.textContent='Ⅱ Pausar';this.playButton.setAttribute('aria-label','Pausar animación')}
    pause(){this.playing=false;if(this.playButton){this.playButton.textContent='▶ Reproducir';this.playButton.setAttribute('aria-label','Reproducir animación')}}
    draw(){if(!this.disposed&&this.camera&&this.renderer&&this.stage.clientWidth)this.renderer.render(this.scene,this.camera)}
    tick(now){if(this.disposed)return;if(!this.container.isConnected){this.dispose();return}const dt=Math.min(.08,(now-this.lastAt)/1000);this.lastAt=now;if(this.playing&&!document.hidden&&this.container.getClientRects().length){if(this.progress>=1){this.endPause+=dt;if(this.endPause>.8){this.endPause=0;this.setProgress(0)}}else this.setProgress(Math.min(1,this.progress+dt*this.speed/this.sign.duration))}this.raf=requestAnimationFrame(this.tick)}
    dispose(){if(this.disposed)return;this.disposed=true;cancelAnimationFrame(this.raf);this.observer?.disconnect();this.abort.abort();this.resources.forEach(x=>x.dispose());this.renderer.dispose();this.renderer.forceContextLoss();this.container.replaceChildren();this.container.classList.remove('sign-viewer')}
  }
  async function mount(container,options={}) {
    if(typeof options.sign==='string'){await ready;options={...options,sign:getSign(options.sign)}}
    if(!options.sign)throw new Error('No hay una animación disponible para este objetivo.');
    try{return new Viewer(container,options)}catch(error){container.replaceChildren(el('p','sign-error','No se pudo abrir la vista 3D. '+error.message));throw error}
  }
  let dialog,dialogViewer,dialogToken=0;
  async function open(target){
    const token=++dialogToken;
    if(!dialog){dialog=el('dialog','sign-dialog');const close=button('×','Cerrar guía 3D');close.classList.add('sign-dialog-close');const content=el('div','sign-dialog-content');dialog.append(close,content);document.body.append(dialog);close.addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});dialog.addEventListener('close',()=>{dialogToken++;dialogViewer?.dispose();dialogViewer=null})}
    dialogViewer?.dispose();dialogViewer=null;const content=dialog.querySelector('.sign-dialog-content');content.replaceChildren(el('p','sign-loading','Preparando guía 3D…'));if(!dialog.open)dialog.showModal();
    try{await ready;if(token!==dialogToken)return;const sign=typeof target==='object'?target:getSign(target);if(!sign)throw new Error('No encontramos una guía para este objetivo.');dialogViewer=await mount(content,{sign});}catch(error){if(token===dialogToken)content.replaceChildren(el('p','sign-error',error.message))}
  }
  window.SenixSigns={ready,getSign,registerSign,loadPersonal,mount,open,validateSign:schema.validateSign,handPose:schema.handPose};
})();
