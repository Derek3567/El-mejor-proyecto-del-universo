/* SENIX procedural sign format, v1. All angles are degrees. No dependencies. */
(function (root, factory) {
    'use strict';
    var api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.SenixSignSchema = api;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';
    var FINGERS = ['thumb', 'index', 'middle', 'ring', 'pinky'];
    var MAX_BYTES = 512 * 1024;
    function object(value) {
        return value !== null && typeof value === 'object' && !Array.isArray(value) &&
            (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
    }
    function own(value, key) { return Object.prototype.hasOwnProperty.call(value, key); }
    function list(value) {
        return Array.isArray(value) && Object.keys(value).length === value.length &&
            Object.keys(value).every(function (key, i) { return key === String(i); });
    }
    function number(value, min, max) { return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max; }
    function string(value, min, max) {
        return typeof value === 'string' && Array.from(value).length >= min && Array.from(value).length <= max &&
            !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value) &&
            !/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(value) &&
            (min === 0 || value.trim().length > 0);
    }
    function normalizeKey(value) {
        return String(value == null ? '' : value).toLowerCase().normalize('NFD')
            .replace(/n\u0303/g, 'ñ').replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9ñ]+/g, '-').replace(/^-+|-+$/g, '');
    }
    function handPose(name) {
        var fingers = { thumb: [0, 0, 0], index: [0, 0, 0], middle: [0, 0, 0], ring: [0, 0, 0], pinky: [0, 0, 0] };
        var spread = { thumb: 35, index: 6, middle: 0, ring: -5, pinky: -10 };
        var opposition = 0;
        if (name === 'fist' || name === 'point') {
            FINGERS.forEach(function (finger) { fingers[finger] = finger === 'thumb' ? [35, 35, 25] : [80, 100, 65]; });
            spread = { thumb: 10, index: 0, middle: 0, ring: 0, pinky: 0 };
            opposition = 35;
            if (name === 'point') fingers.index = [0, 0, 0];
        } else if (name === 'pinch') {
            fingers.thumb = [20, 25, 30];
            fingers.index = [40, 55, 35];
            opposition = 55;
            spread.thumb = 10;
        } else if (name !== undefined && name !== 'open') {
            throw new RangeError('Pose desconocida. Usa open, fist, point o pinch.');
        }
        return { position: [0, -1, 0], rotation: [0, 0, 0], fingers: fingers, spread: spread, thumbOpposition: opposition };
    }
    function validateSign(sign) {
        var errors = [];
        function fail(path, message) { if (errors.length < 50) errors.push(path + ': ' + message); }
        function keys(value, required, optional, path) {
            if (!object(value)) { fail(path, 'debe ser un objeto JSON.'); return false; }
            required.forEach(function (key) { if (!own(value, key)) fail(path + '.' + key, 'falta este campo.'); });
            Object.keys(value).forEach(function (key) {
                if (required.indexOf(key) === -1 && optional.indexOf(key) === -1) fail(path, 'contiene un campo no reconocido.');
            });
            return true;
        }
        function text(value, min, max, path) {
            if (!string(value, min, max)) fail(path, 'debe ser texto de ' + min + ' a ' + max + ' caracteres.');
        }
        function numeric(value, min, max, path) {
            if (!number(value, min, max)) fail(path, 'debe ser un número finito entre ' + min + ' y ' + max + '.');
        }
        function triple(value, min, max, path) {
            if (!list(value) || value.length !== 3) { fail(path, 'debe contener exactamente tres números.'); return; }
            for (var i = 0; i < 3; i++) numeric(value[i], min, max, path + '[' + i + ']');
        }
        function hand(value, path) {
            if (value === null) return;
            if (!keys(value, ['position', 'rotation', 'fingers', 'spread', 'thumbOpposition'], [], path)) return;
            triple(value.position, -8, 8, path + '.position');
            triple(value.rotation, -360, 360, path + '.rotation');
            numeric(value.thumbOpposition, -90, 180, path + '.thumbOpposition');
            if (keys(value.fingers, FINGERS, [], path + '.fingers')) {
                FINGERS.forEach(function (finger) { triple(value.fingers[finger], -30, 160, path + '.fingers.' + finger); });
            }
            if (keys(value.spread, FINGERS, [], path + '.spread')) {
                FINGERS.forEach(function (finger) { numeric(value.spread[finger], -90, 90, path + '.spread.' + finger); });
            }
        }
        if (!keys(sign, ['id', 'label', 'kind', 'description', 'instructions', 'status', 'duration', 'body', 'frames'], ['aliases', 'sourceUrls'], 'seña')) return { valid: false, errors: errors };
        text(sign.id, 1, 100, 'id');
        text(sign.label, 1, 120, 'label');
        text(sign.description, 0, 3000, 'description');
        if (['letter', 'number', 'word', 'phrase'].indexOf(sign.kind) === -1) fail('kind', 'usa letter, number, word o phrase.');
        if (['draft', 'reviewed'].indexOf(sign.status) === -1) fail('status', 'usa draft o reviewed.');
        numeric(sign.duration, 0.5, 60, 'duration');
        if (typeof sign.body !== 'boolean') fail('body', 'debe ser true o false.');
        if (!list(sign.instructions) || sign.instructions.length > 30) fail('instructions', 'debe ser una lista de hasta 30 instrucciones.');
        else sign.instructions.forEach(function (item, i) { text(item, 1, 500, 'instructions[' + i + ']'); });
        if (own(sign, 'aliases')) {
            if (!list(sign.aliases) || sign.aliases.length > 40) fail('aliases', 'debe ser una lista de hasta 40 nombres alternativos.');
            else sign.aliases.forEach(function (item, i) { text(item, 1, 120, 'aliases[' + i + ']'); });
        }
        if (own(sign, 'sourceUrls')) {
            if (!list(sign.sourceUrls) || sign.sourceUrls.length > 20) fail('sourceUrls', 'debe ser una lista de hasta 20 referencias HTTPS.');
            else sign.sourceUrls.forEach(function (item, i) {
                var valid = string(item, 1, 2048) && /^https:\/\//i.test(item) && !/[\s\\]/.test(item);
                if (valid) {
                    try { var url = new URL(item); valid = url.protocol === 'https:' && !!url.hostname && !url.username && !url.password; }
                    catch (_) { valid = false; }
                }
                if (!valid) fail('sourceUrls[' + i + ']', 'usa una dirección HTTPS completa sin credenciales.');
            });
        }
        if (!list(sign.frames) || sign.frames.length < 2 || sign.frames.length > 120) fail('frames', 'incluye entre 2 y 120 poses completas.');
        else {
            var previous = -1;
            sign.frames.forEach(function (frame, i) {
                var path = 'frames[' + i + ']';
                if (!keys(frame, ['t', 'cue', 'right', 'left'], [], path)) return;
                numeric(frame.t, 0, 1, path + '.t');
                if (typeof frame.t === 'number' && frame.t <= previous) fail(path + '.t', 'los tiempos deben aumentar sin repetirse.');
                previous = frame.t;
                text(frame.cue, 0, 500, path + '.cue');
                hand(frame.right, path + '.right'); hand(frame.left, path + '.left');
                if (frame.right === null && frame.left === null) fail(path, 'debe mostrar al menos una mano.');
            });
            if (!sign.frames[0] || sign.frames[0].t !== 0) fail('frames[0].t', 'la primera pose debe empezar en 0.');
            if (!sign.frames[sign.frames.length - 1] || sign.frames[sign.frames.length - 1].t !== 1) fail('frames', 'la última pose debe terminar en 1.');
        }
        try {
            var json = JSON.stringify(sign);
            var bytes = typeof TextEncoder === 'function' ? new TextEncoder().encode(json).length : unescape(encodeURIComponent(json)).length;
            if (bytes > MAX_BYTES) fail('seña', 'supera el límite de 512 KiB.');
        } catch (_) { fail('seña', 'debe poder serializarse como JSON.'); }
        return { valid: errors.length === 0, errors: errors };
    }
    return { validateSign: validateSign, normalizeKey: normalizeKey, handPose: handPose };
}));
