/* Selector compartido para las cámaras que el navegador reconoce. */
(() => {
  'use strict';
  const selectors = new Set();
  const mounted = new WeakMap();

  async function refresh(select, activeStream) {
    if (!select || !navigator.mediaDevices?.enumerateDevices) return;
    try {
      const devices = (await navigator.mediaDevices.enumerateDevices()).filter(item => item.kind === 'videoinput');
      const activeId = activeStream?.getVideoTracks()[0]?.getSettings().deviceId || '';
      const wanted = select.value || activeId;
      select.replaceChildren(new Option('Cámara predeterminada', ''));
      devices.forEach((device, index) => {
        select.add(new Option(device.label || `Cámara ${index + 1}`, device.deviceId));
      });
      select.value = devices.some(device => device.deviceId === wanted) ? wanted : '';
      select.disabled = devices.length < 2;
      select.parentElement.hidden = devices.length < 2;
    } catch (_) {
      select.parentElement.hidden = true;
    }
  }

  function attach(startButton, getStream, restart) {
    if (!startButton || mounted.has(startButton)) return mounted.get(startButton);
    const wrapper = document.createElement('label');
    wrapper.className = 'senix-camera-picker';
    wrapper.hidden = true;
    wrapper.textContent = 'Cámara ';
    const select = document.createElement('select');
    select.setAttribute('aria-label', 'Elegir cámara');
    wrapper.append(select);
    const actions = startButton.closest('.lesson-camera-actions,.practice-camera-actions,.quick-camera-actions,.video-call-actions');
    (actions?.parentElement || startButton.parentElement).insertBefore(wrapper, actions || startButton);
    selectors.add({ select, getStream });
    select.addEventListener('change', () => {
      if (getStream()?.active) restart();
    });
    mounted.set(startButton, select);
    refresh(select, getStream());
    return select;
  }

  function constraints(select, defaults = {}) {
    return select?.value ? { ...defaults, deviceId: { exact: select.value } } : { ...defaults, facingMode: 'user' };
  }

  function sync(stream) {
    for (const item of selectors) refresh(item.select, item.getStream() || stream);
  }

  navigator.mediaDevices?.addEventListener?.('devicechange', () => sync());
  window.SenixCameraDevices = { attach, constraints, sync };
})();
