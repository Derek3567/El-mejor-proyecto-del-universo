(() => {
  'use strict';
  const board = document.getElementById('memory-board');
  if (!board) return;
  const status = document.getElementById('memory-status');
  const moves = document.getElementById('memory-moves');
  const pairs = document.getElementById('memory-pairs');
  const values = [
    ['A', 'Puño; pulgar al costado'],
    ['B', 'Dedos juntos; pulgar recogido'],
    ['L', 'Índice y pulgar en L'],
    ['V', 'Índice y medio separados'],
    ['W', 'Tres dedos abiertos'],
    ['Y', 'Pulgar y meñique abiertos']
  ];
  let open = [], found = 0, attempts = 0, blocked = false, timer = null;
  function shuffle(items) {
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [items[i], items[j]] = [items[j], items[i]];
    }
    return items;
  }
  function reset() {
    clearTimeout(timer); open = []; found = 0; attempts = 0; blocked = false;
    moves.textContent = '0 intentos'; pairs.textContent = '0 de 6 pares';
    status.textContent = 'Selecciona dos cartas para comenzar.';
    board.replaceChildren();
    shuffle(values.flatMap(([letter, clue], index) => [
      { pair: index, label: letter, kind: 'letter' }, { pair: index, label: clue, kind: 'clue' }
    ])).forEach(card => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'memory-card';
      button.dataset.pair = String(card.pair); button.dataset.label = card.label;
      button.classList.add('memory-' + card.kind);
      button.setAttribute('aria-label', 'Carta oculta'); button.textContent = '?';
      button.addEventListener('click', () => turn(button)); board.append(button);
    });
  }
  function turn(card) {
    if (blocked || card.classList.contains('revealed') || card.classList.contains('matched')) return;
    card.classList.add('revealed'); card.textContent = card.dataset.label;
    card.setAttribute('aria-label', card.dataset.label);
    open.push(card);
    if (open.length !== 2) return;
    attempts++; moves.textContent = attempts + (attempts === 1 ? ' intento' : ' intentos');
    const [first, second] = open;
    if (first.dataset.pair === second.dataset.pair) {
      first.classList.add('matched'); second.classList.add('matched');
      first.disabled = second.disabled = true; open = []; found++;
      pairs.textContent = found + ' de 6 pares';
      window.SenixSound?.play('success');
      status.textContent = found === 6 ? `¡Completaste el juego en ${attempts} intentos!` : '¡Pareja encontrada!';
    } else {
      blocked = true; window.SenixSound?.play('error');
      status.textContent = 'No forman pareja. Intenta otra vez.';
      timer = setTimeout(() => {
        for (const item of open) {
          item.classList.remove('revealed'); item.textContent = '?';
          item.setAttribute('aria-label', 'Carta oculta');
        }
        open = []; blocked = false;
      }, 850);
    }
  }
  document.getElementById('memory-restart').addEventListener('click', reset);
  reset();
})();
