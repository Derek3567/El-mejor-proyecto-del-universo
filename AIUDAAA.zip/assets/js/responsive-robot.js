/* El robot 3D solo se solicita en pantallas amplias. */
(() => {
  'use strict';
  const robot = document.querySelector('[data-desktop-robot]');
  if (!robot) return;
  const desktop = matchMedia('(min-width: 769px)');
  function update() {
    if (desktop.matches) {
      if (!robot.src) robot.src = robot.dataset.desktopRobot;
    } else {
      robot.removeAttribute('src');
    }
  }
  desktop.addEventListener?.('change', update);
  update();
})();
