# Sonidos SENIX

Los archivos incluidos son sonidos originales sintetizados para este proyecto:

- `ambient.wav`: fondo discreto en bucle.
- `click.wav`: clic proporcionado por el equipo, recortado a 0.24 segundos y sin el silencio inicial.
- `transition.wav`: cambio de sección.
- `success.wav`: acierto o logro.
- `error.wav`: error o respuesta incorrecta.

El sonido se activa con el botón «Sin sonido». El navegador exige una interacción antes de reproducir audio. La preferencia se guarda en este navegador.
