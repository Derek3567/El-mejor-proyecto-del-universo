<?php
/** Utilidades compartidas para los perfiles de Senix. */

if (basename($_SERVER['PHP_SELF'] ?? '') === 'profile-tools.php') {
    http_response_code(403);
    exit('Acceso denegado');
}

function profile_ensure_schema(PDO $db): bool {
    static $ready = null;
    if ($ready !== null) return $ready;

    $columns = [];
    foreach ($db->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_ASSOC) as $column) {
        $columns[(string)$column['Field']] = true;
    }

    if (!isset($columns['bio'])) {
        $db->exec("ALTER TABLE users ADD COLUMN bio VARCHAR(150) DEFAULT NULL AFTER avatar");
    }
    if (!isset($columns['profile_frame'])) {
        $db->exec("ALTER TABLE users ADD COLUMN profile_frame VARCHAR(12) NOT NULL DEFAULT 'none' AFTER bio");
    }
    if (!isset($columns['profile_banner'])) {
        $db->exec("ALTER TABLE users ADD COLUMN profile_banner VARCHAR(180) DEFAULT NULL AFTER profile_frame");
    }

    return $ready = true;
}

function profile_frame_value($value): string {
    $value = strtolower(trim((string)$value));
    return in_array($value, ['none', 'light', 'rgb', 'fire', 'air', 'water', 'earth', 'gold', 'aurora', 'galaxy', 'sakura', 'crystal', 'sunset', 'forest', 'moon', 'neon'], true) ? $value : 'none';
}

function profile_frame_requirements(): array {
    return ['light'=>'first_lesson','rgb'=>'detection_1000','fire'=>'streak_7','air'=>'early_bird','water'=>'vocab_master','earth'=>'teacher_helper','gold'=>'perfect_lesson','aurora'=>'streak_30','galaxy'=>'expert_signer','sakura'=>'social_butterfly','crystal'=>'accuracy_90','sunset'=>'night_owl','forest'=>'alphabet_master','moon'=>'simulator_ace','neon'=>'perfectionist'];
}

function profile_unlocked_frames(PDO $db, int $userId, string $current = 'none'): array {
    $unlocked = ['none' => true];
    $requirements = profile_frame_requirements();
    try {
        $q = $db->prepare("SELECT a.code FROM user_achievements ua JOIN achievements a ON a.id=ua.achievement_id WHERE ua.user_id=? AND ua.unlocked=1");
        $q->execute([$userId]);
        $codes = array_fill_keys(array_map('strval', $q->fetchAll(PDO::FETCH_COLUMN)), true);
        foreach ($requirements as $frame => $code) if (isset($codes[$code])) $unlocked[$frame] = true;
    } catch (Throwable $e) { error_log('[Senix frame unlocks] '.$e->getMessage()); }
    $current = profile_frame_value($current);
    if ($current !== 'none') $unlocked[$current] = true;
    return array_keys($unlocked);
}

function profile_banner_src(array $profile): string {
    $filename = basename(str_replace('\\', '/', trim((string)($profile['profile_banner'] ?? ''))));
    if ($filename === '' || $filename === '.' || $filename === '..') return '';
    return url('uploads/banners/' . rawurlencode($filename));
}
function profile_avatar_src(array $profile): string {
    $avatar = trim((string)($profile['avatar'] ?? ''));
    if ($avatar === '' || $avatar === 'default.png') return '';

    if (preg_match('~^https://~i', $avatar) && filter_var($avatar, FILTER_VALIDATE_URL)) {
        return $avatar;
    }

    $filename = basename(str_replace('\\', '/', $avatar));
    if ($filename === '' || $filename === '.' || $filename === '..') return '';
    return url('uploads/avatars/' . rawurlencode($filename));
}

function profile_client_payload(array $profile): array {
    $profile['bio'] = (string)($profile['bio'] ?? '');
    $profile['profile_frame'] = profile_frame_value($profile['profile_frame'] ?? 'none');
    $profile['avatar_url'] = profile_avatar_src($profile);
    $profile['banner_url'] = profile_banner_src($profile);
    return $profile;
}

