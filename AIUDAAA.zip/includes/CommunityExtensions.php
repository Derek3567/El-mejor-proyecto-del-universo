<?php
/** Community wall and group conversation endpoints. */

if (basename($_SERVER['PHP_SELF'] ?? '') === 'CommunityExtensions.php') {
    http_response_code(403);
    exit('Acceso denegado');
}

function community_extensions_schema(PDO $db): void {
    static $ready = false;
    if ($ready) return;
    $statements = [
        "CREATE TABLE IF NOT EXISTS community_posts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT UNSIGNED NOT NULL,body VARCHAR(500) NOT NULL DEFAULT '',photo_name VARCHAR(180) DEFAULT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_community_post_created(created_at),KEY idx_community_post_user(user_id),CONSTRAINT fk_community_post_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS community_post_comments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,post_id BIGINT UNSIGNED NOT NULL,user_id INT UNSIGNED NOT NULL,body VARCHAR(500) NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_community_comment_post(post_id,id),CONSTRAINT fk_community_comment_post FOREIGN KEY(post_id) REFERENCES community_posts(id) ON DELETE CASCADE,CONSTRAINT fk_community_comment_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS community_groups (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(60) NOT NULL,owner_id INT UNSIGNED NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_community_group_updated(updated_at),CONSTRAINT fk_community_group_owner FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS community_group_members (group_id BIGINT UNSIGNED NOT NULL,user_id INT UNSIGNED NOT NULL,last_read_id BIGINT UNSIGNED NOT NULL DEFAULT 0,joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(group_id,user_id),KEY idx_community_group_member_user(user_id),CONSTRAINT fk_community_group_member_group FOREIGN KEY(group_id) REFERENCES community_groups(id) ON DELETE CASCADE,CONSTRAINT fk_community_group_member_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS community_group_messages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,group_id BIGINT UNSIGNED NOT NULL,sender_id INT UNSIGNED NOT NULL,body VARCHAR(199) NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,KEY idx_community_group_message(group_id,id),CONSTRAINT fk_community_group_message_group FOREIGN KEY(group_id) REFERENCES community_groups(id) ON DELETE CASCADE,CONSTRAINT fk_community_group_message_sender FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    ];
    foreach ($statements as $sql) $db->exec($sql);
    $ready = true;
}

function community_extension_text($value, int $max): string {
    $value = trim((string)$value);
    return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
}

function community_extension_member(PDO $db, int $groupId, int $userId): bool {
    $q = $db->prepare('SELECT 1 FROM community_group_members WHERE group_id=? AND user_id=?');
    $q->execute([$groupId, $userId]);
    return (bool)$q->fetchColumn();
}

function community_extended_handle(PDO $db, int $uid, string $method, string $action): void {
    if (!in_array($action, ['feed','post','comment','group-overview','create-group','group-messages','group-send'], true)) return;
    community_extensions_schema($db);
    if ($action === 'feed' && $method === 'GET') {
        $posts=$db->query("SELECT p.id,p.user_id,p.body,p.photo_name,p.created_at,u.username,u.full_name,u.avatar,u.profile_frame FROM community_posts p JOIN users u ON u.id=p.user_id WHERE u.is_active=1 ORDER BY p.created_at DESC,p.id DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC);
        $eventQuery=$db->prepare("SELECT e.id,e.user_id,e.event_type,e.event_key,e.title,e.details,e.created_at,u.username,u.full_name,u.avatar,u.profile_frame FROM community_activity_events e JOIN users u ON u.id=e.user_id WHERE u.is_active=1 AND (u.is_public=1 OR u.id=?) ORDER BY e.created_at DESC,e.id DESC LIMIT 40");$eventQuery->execute([$uid]);$events=$eventQuery->fetchAll(PDO::FETCH_ASSOC);
        foreach($posts as &$post){$post['kind']='post';$q=$db->prepare('SELECT c.id,c.body,c.created_at,u.id user_id,u.username,u.full_name,u.avatar,u.profile_frame FROM community_post_comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? AND u.is_active=1 ORDER BY c.id ASC LIMIT 30');$q->execute([(int)$post['id']]);$post['comments']=$q->fetchAll(PDO::FETCH_ASSOC);}unset($post);
        foreach($events as &$event)$event['kind']='event';unset($event);
        $feed=array_merge($posts,$events);usort($feed,static fn($a,$b)=>strcmp((string)$b['created_at'],(string)$a['created_at']));
        api_json(['success'=>true,'items'=>array_slice($feed,0,60)]);
    }
    if ($action === 'post' && $method === 'POST') {
        $body=community_extension_text($_POST['body']??'',500);$photoName=null;
        if(isset($_FILES['photo'])&&(int)($_FILES['photo']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){$upload=(new Uploader('community'))->uploadImage($_FILES['photo'],['max_size'=>4*1024*1024,'max_width'=>2400,'max_height'=>2400,'prefix'=>'post']);if(empty($upload['success']))api_json(['error'=>$upload['error']??'No se pudo guardar la imagen.'],422);$photoName=basename((string)$upload['filename']);}
        if($body===''&&$photoName===null)api_json(['error'=>'Escribe algo o añade una foto.'],422);
        $q=$db->prepare('INSERT INTO community_posts(user_id,body,photo_name) VALUES(?,?,?)');$q->execute([$uid,$body,$photoName]);global $achievementModel;try{if(isset($achievementModel))$achievementModel->checkAll($uid);}catch(Throwable $e){error_log('[Senix social achievement check] '. $e->getMessage());}api_json(['success'=>true,'id'=>(int)$db->lastInsertId()]);
    }
    if ($action === 'comment' && $method === 'POST') {
        $postId=(int)($_POST['post_id']??0);$body=community_extension_text($_POST['body']??'',500);if($postId<1||$body==='')api_json(['error'=>'Escribe un comentario.'],422);
        $q=$db->prepare('SELECT 1 FROM community_posts p JOIN users u ON u.id=p.user_id WHERE p.id=? AND u.is_active=1');$q->execute([$postId]);if(!$q->fetchColumn())api_json(['error'=>'La publicación ya no está disponible.'],404);
        $q=$db->prepare('INSERT INTO community_post_comments(post_id,user_id,body) VALUES(?,?,?)');$q->execute([$postId,$uid,$body]);api_json(['success'=>true]);
    }
    if ($action === 'group-overview' && $method === 'GET') {
        $q=$db->prepare("SELECT g.id,g.name,g.owner_id,g.updated_at,(SELECT COUNT(*) FROM community_group_members m WHERE m.group_id=g.id) member_count,(SELECT COUNT(*) FROM community_group_messages msg WHERE msg.group_id=g.id AND msg.id>mine.last_read_id AND msg.sender_id<>?) unread,(SELECT msg.body FROM community_group_messages msg WHERE msg.group_id=g.id ORDER BY msg.id DESC LIMIT 1) last_message FROM community_groups g JOIN community_group_members mine ON mine.group_id=g.id AND mine.user_id=? ORDER BY g.updated_at DESC,g.id DESC");$q->execute([$uid,$uid]);api_json(['success'=>true,'groups'=>$q->fetchAll(PDO::FETCH_ASSOC)]);
    }
    if ($action === 'create-group' && $method === 'POST') {
        $name=community_extension_text($_POST['name']??'',60);$memberIds=$_POST['member_ids']??[];if($name===''||strlen($name)<2)api_json(['error'=>'El nombre del grupo debe tener al menos 2 caracteres.'],422);if(!is_array($memberIds))$memberIds=[];
        $memberIds=array_values(array_unique(array_filter(array_map('intval',$memberIds),static fn($id)=>$id>0&&$id!==$uid)));if(count($memberIds)<1||count($memberIds)>19)api_json(['error'=>'Elige entre 1 y 19 amistades para crear un grupo.'],422);
        $q=$db->prepare('SELECT user_low_id,user_high_id FROM community_friendships WHERE user_low_id=? OR user_high_id=?');$q->execute([$uid,$uid]);$friends=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $pair)$friends[]=(int)($pair['user_low_id']==$uid?$pair['user_high_id']:$pair['user_low_id']);foreach($memberIds as $memberId)if(!in_array($memberId,$friends,true))api_json(['error'=>'Los grupos solo pueden incluir amistades aceptadas.'],403);
        $db->beginTransaction();try{$q=$db->prepare('INSERT INTO community_groups(name,owner_id) VALUES(?,?)');$q->execute([$name,$uid]);$groupId=(int)$db->lastInsertId();$memberIds[]=$uid;$add=$db->prepare('INSERT INTO community_group_members(group_id,user_id) VALUES(?,?)');foreach($memberIds as $memberId)$add->execute([$groupId,$memberId]);$db->commit();}catch(Throwable $error){if($db->inTransaction())$db->rollBack();throw $error;}
        api_json(['success'=>true,'group_id'=>$groupId]);
    }
    if ($action === 'group-messages' && $method === 'GET') {
        $groupId=(int)($_GET['group_id']??0);if($groupId<1||!community_extension_member($db,$groupId,$uid))api_json(['error'=>'No tienes acceso a este grupo.'],403);
        $q=$db->prepare('SELECT id,body,created_at,sender_id FROM community_group_messages WHERE group_id=? ORDER BY id DESC LIMIT 80');$q->execute([$groupId]);$messages=array_reverse($q->fetchAll(PDO::FETCH_ASSOC));$q=$db->prepare('SELECT u.id,u.username,u.full_name,u.avatar,u.profile_frame FROM community_group_members m JOIN users u ON u.id=m.user_id WHERE m.group_id=? AND u.is_active=1 ORDER BY u.username');$q->execute([$groupId]);$members=$q->fetchAll(PDO::FETCH_ASSOC);
        $lastId=$messages?(int)$messages[count($messages)-1]['id']:0;$q=$db->prepare('UPDATE community_group_members SET last_read_id=GREATEST(last_read_id,?) WHERE group_id=? AND user_id=?');$q->execute([$lastId,$groupId,$uid]);api_json(['success'=>true,'messages'=>$messages,'members'=>$members]);
    }
    if ($action === 'group-send' && $method === 'POST') {
        $groupId=(int)($_POST['group_id']??0);$body=community_extension_text($_POST['body']??'',199);if($groupId<1||!community_extension_member($db,$groupId,$uid))api_json(['error'=>'No tienes acceso a este grupo.'],403);if($body==='')api_json(['error'=>'Escribe un mensaje.'],422);
        $q=$db->prepare('INSERT INTO community_group_messages(group_id,sender_id,body) VALUES(?,?,?)');$q->execute([$groupId,$uid,$body]);$q=$db->prepare('UPDATE community_groups SET updated_at=UTC_TIMESTAMP() WHERE id=?');$q->execute([$groupId]);api_json(['success'=>true,'id'=>(int)$db->lastInsertId()]);
    }
}
