<?php
/** Respuestas JSON seguras para los endpoints asíncronos de Senix. */

if (basename($_SERVER['PHP_SELF'] ?? '') === 'api-tools.php') {
    http_response_code(403);
    exit('Acceso denegado');
}

function api_prepare(): void {
    if (ob_get_level() > 0 && ob_get_length()) {
        ob_clean();
    }
    ini_set('display_errors', '0');
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
}

function api_json(array $payload, int $status = 200): never {
    if (ob_get_level() > 0) {
        ob_clean();
    }

    api_prepare();
    http_response_code($status);
    $json = json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
    );
    echo $json === false ? '{"error":"No se pudo preparar la respuesta."}' : $json;
    exit;
}

function api_require_login($auth, string $message): void {
    if (!$auth->isLoggedIn()) {
        api_json(['error' => $message, 'code' => 'session_expired'], 401);
    }
}

function api_verify_csrf(): void {
    $token = (string)($_POST['csrf_token'] ?? '');
    $stored = (string)($_SESSION['learn_csrf'] ?? '');
    if ($token === '' || $stored === '' || !hash_equals($stored, $token)) {
        api_json([
            'error' => 'Tu sesión expiró. Recarga la página e inténtalo de nuevo.',
            'code' => 'csrf_expired',
        ], 419);
    }
}
