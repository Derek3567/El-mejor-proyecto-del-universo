<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/CommunityFeed.php';
if (!$auth->isLoggedIn()) redirect(APP_URL . '/login.php');
$learnUser=$auth->user() ?: []; $learnUserId=(int)($learnUser['id']??0);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['learn_csrf'])) $_SESSION['learn_csrf']=bin2hex(random_bytes(32));
function learn_h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function learn_csrf(){return '<input type="hidden" name="csrf_token" value="'.learn_h($_SESSION['learn_csrf']).'">';}
function learn_verify_csrf(){ $t=(string)($_POST['csrf_token']??''); if(!$t||!hash_equals((string)($_SESSION['learn_csrf']??''),$t)){http_response_code(419);exit('La sesión del formulario expiró. Recarga la página e inténtalo de nuevo.');}}
function learn_db(){global $pdo;return $pdo;}
function learn_ensure_tables(){
 static $checked=false; if($checked)return true;
 $sqls=[
 "CREATE TABLE IF NOT EXISTS custom_lessons (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT UNSIGNED NOT NULL,title VARCHAR(120) NOT NULL,description VARCHAR(500) DEFAULT '',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),CONSTRAINT fk_custom_lesson_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS custom_lesson_items (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,custom_lesson_id BIGINT UNSIGNED NOT NULL,prompt VARCHAR(255) NOT NULL,answer VARCHAR(255) NOT NULL,options_json TEXT NOT NULL,order_index INT NOT NULL DEFAULT 0,CONSTRAINT fk_custom_item_lesson FOREIGN KEY(custom_lesson_id) REFERENCES custom_lessons(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS custom_lesson_progress (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,custom_lesson_id BIGINT UNSIGNED NOT NULL,user_id INT UNSIGNED NOT NULL,score INT NOT NULL,question_count INT NOT NULL,completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),CONSTRAINT fk_clp_lesson FOREIGN KEY(custom_lesson_id) REFERENCES custom_lessons(id) ON DELETE CASCADE,CONSTRAINT fk_clp_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS daily_challenge_progress (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,challenge_date DATE NOT NULL,user_id INT UNSIGNED NOT NULL,score INT NOT NULL DEFAULT 0,completed TINYINT(1) NOT NULL DEFAULT 0,completed_at DATETIME DEFAULT NULL,UNIQUE KEY uq_daily_user(challenge_date,user_id),CONSTRAINT fk_dcp_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS skill_assessments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT UNSIGNED NOT NULL,score INT NOT NULL,total INT NOT NULL,level_label VARCHAR(40) NOT NULL,answers_json TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(user_id,created_at),CONSTRAINT fk_skill_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS user_curriculum_progress (user_id INT UNSIGNED NOT NULL,lesson_key VARCHAR(16) NOT NULL,lesson_order SMALLINT UNSIGNED NOT NULL,section_no TINYINT UNSIGNED NOT NULL,lesson_index TINYINT UNSIGNED NOT NULL,xp_awarded INT UNSIGNED NOT NULL DEFAULT 0,timezone VARCHAR(64) NOT NULL DEFAULT 'America/Mexico_City',completed_at_utc DATETIME NOT NULL,PRIMARY KEY(user_id,lesson_key),UNIQUE KEY uq_user_curriculum_order(user_id,lesson_order),KEY idx_curriculum_completed(completed_at_utc),CONSTRAINT fk_curriculum_progress_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "CREATE TABLE IF NOT EXISTS user_curriculum_results (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT UNSIGNED NOT NULL,lesson_key VARCHAR(16) NOT NULL,quiz_score TINYINT UNSIGNED NOT NULL DEFAULT 0,quiz_total TINYINT UNSIGNED NOT NULL DEFAULT 0,time_spent INT UNSIGNED NOT NULL DEFAULT 0,completed_at_utc DATETIME NOT NULL,UNIQUE KEY uq_user_curriculum_result(user_id,lesson_key),CONSTRAINT fk_curriculum_result_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
 ];
 $sqls[]="CREATE TABLE IF NOT EXISTS user_curriculum_attempts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT UNSIGNED NOT NULL,lesson_key VARCHAR(16) NOT NULL,elapsed_seconds INT UNSIGNED NOT NULL DEFAULT 0,camera_samples INT UNSIGNED NOT NULL DEFAULT 0,camera_seen_samples INT UNSIGNED NOT NULL DEFAULT 0,camera_visible_ms INT UNSIGNED NOT NULL DEFAULT 0,camera_fps DECIMAL(5,1) NOT NULL DEFAULT 0,items_completed SMALLINT UNSIGNED NOT NULL DEFAULT 0,quiz_score TINYINT UNSIGNED NOT NULL DEFAULT 0,quiz_total TINYINT UNSIGNED NOT NULL DEFAULT 0,xp_awarded INT UNSIGNED NOT NULL DEFAULT 0,completed_at_utc DATETIME NOT NULL,KEY idx_learning_attempt_user_date(user_id,completed_at_utc),KEY idx_learning_attempt_lesson(user_id,lesson_key),CONSTRAINT fk_learning_attempt_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
 $ok=true; foreach($sqls as $sql){try{learn_db()->exec($sql);}catch(Throwable $e){$ok=false;error_log('[Senix learning schema] '.$e->getMessage());}}
 $checked=$ok; return $ok;
}
function learn_header($title,$subtitle='',$extraCss=[]){
    $u=learn_h($title);$s=learn_h($subtitle);$url=learn_h(APP_URL);$extraLinks='';
    foreach((array)$extraCss as $css)$extraLinks.='<link rel="stylesheet" href="'.learn_h(asset('css/'.$css)).'">';
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$u.' · Senix</title><link rel="stylesheet" href="'.learn_h(asset('css/menu.css')).'"><link rel="stylesheet" href="'.learn_h(asset('css/learning-tools.css')).'"><link rel="stylesheet" href="'.learn_h(asset('css/learning-type.css')).'">'.$extraLinks.'<link rel="stylesheet" href="'.learn_h(asset('css/priority-2026.css')).'?v=20261026-4"></head><body class="sx-app"><main class="learn-tool-shell"><header class="learn-tool-top"><a href="'.$url.'/menu.php#practice">← Volver a Senix</a><span>✦ SENIX · APRENDIZAJE</span><a href="'.$url.'/logout.php">Cerrar sesión</a></header><section class="learn-tool-heading"><span class="eyebrow">TU ESPACIO DE APRENDIZAJE</span><h1>'.$u.'</h1>'.($s?'<p>'.$s.'</p>':'').'</section>';
}function learn_footer(){echo '</main><script src="'.learn_h(asset('js/senix-sound.js')).'?v=20261026-2" defer></script></body></html>';}
function learn_flash($message){echo '<div class="learn-notice" role="status">'.learn_h($message).'</div>'; }
function learn_redirect(string $url): never { header('Location: '.$url, true, 303); exit; }
function learn_curriculum_catalog(): array {
    static $catalog=null;
    if(is_array($catalog))return $catalog;
    $path=__DIR__.'/../assets/data/learning-curriculum.json';
    $raw=@file_get_contents($path);
    $data=is_string($raw)?json_decode($raw,true):null;
    if(!is_array($data)||!is_array($data['sections']??null)||count($data['sections'])!==3)throw new RuntimeException('El catálogo de aprendizaje LSM no está disponible.');
    $catalog=$data;
    return $catalog;
}
function learn_curriculum_lesson(string $key): ?array {
    if(!preg_match('/^s([1-3])-([0-9]{1,2})$/',$key,$match))return null;
    $sectionNo=(int)$match[1];$lessonIndex=(int)$match[2];$catalog=learn_curriculum_catalog();
    $section=$catalog['sections'][$sectionNo-1]??null;$lesson=$section['lessons'][$lessonIndex]??null;
    if(!is_array($section)||!is_array($lesson)||!is_array($lesson['items']??null)||count($lesson['items'])<2)return null;
    $order=0;foreach(array_slice($catalog['sections'],0,$sectionNo-1) as $previous)$order+=count($previous['lessons']??[]);$order+=$lessonIndex;
    return ['key'=>$key,'order'=>$order,'section'=>$sectionNo,'index'=>$lessonIndex,'xp'=>[20,30,40][$sectionNo-1],'section_data'=>$section,'lesson'=>$lesson];
}
function learn_curriculum(): array {
    $items=[];$catalog=learn_curriculum_catalog();
    foreach($catalog['sections'] as $section=>$definition)foreach(($definition['lessons']??[]) as $index=>$lesson)$items[]=['key'=>'s'.($section+1).'-'.$index,'order'=>count($items),'section'=>$section+1,'index'=>$index,'xp'=>[20,30,40][$section]];
    return $items;
}
function learn_normalize_term(string $value): string {
    $value=function_exists('mb_strtolower')?mb_strtolower(trim($value),'UTF-8'):strtolower(trim($value));
    $value=strtr($value,['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u','ñ'=>'n','Á'=>'a','É'=>'e','Í'=>'i','Ó'=>'o','Ú'=>'u','Ü'=>'u','Ñ'=>'n']);
    return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));
}
function learn_sign_reference(string $target): ?array {
    static $references=null;
    if($references===null){$path=__DIR__.'/../assets/data/signs-lsm.json';$raw=@file_get_contents($path);$data=is_string($raw)?json_decode($raw,true):null;$references=is_array($data['signs']??null)?$data['signs']:[];}
    $needle=learn_normalize_term($target);
    foreach($references as $sign){if(!is_array($sign))continue;$labels=array_merge([(string)($sign['label']??'')],is_array($sign['aliases']??null)?$sign['aliases']:[]);foreach($labels as $label)if(learn_normalize_term((string)$label)===$needle)return $sign;}
    return null;
}
function learn_curriculum_build_quiz(string $key): array {
    if(!learn_curriculum_lesson($key))return ['client'=>[],'stored'=>[]];
    return learn_build_lsm_quiz();
}
function learn_build_lsm_quiz(): array {
    $bank=[
        ['prompt'=>'¿Qué describe mejor a la Lengua de Señas Mexicana (LSM)?','correct'=>'Una lengua natural con vocabulario y gramática propios.','choices'=>['Español hablado representado solamente con las manos.','Un alfabeto manual sin reglas gramaticales.','Una colección universal de gestos idéntica en todos los países.'],'explanation'=>'La LSM es una lengua propia de la comunidad sorda mexicana; no es una traducción manual palabra por palabra del español.','source'=>'SIL México','source_url'=>'https://mexico.sil.org/es/lengua_cultura/lenguas-de-se%C3%B1as-en-m%C3%A9xico'],
        ['prompt'=>'¿Cómo se relaciona la LSM con el español?','correct'=>'La LSM tiene una gramática propia; no es español codificado con señas.','choices'=>['Cada seña sustituye exactamente una palabra española.','La LSM es un sistema internacional único.','La LSM no tiene estructura lingüística.'],'explanation'=>'Las lenguas de señas son lenguas naturales y tienen estructuras que no se reducen al orden del español.','source'=>'SIL México','source_url'=>'https://mexico.sil.org/es/lengua_cultura/lenguas-de-se%C3%B1as-en-m%C3%A9xico'],
        ['prompt'=>'Además de la forma de la mano, ¿qué elementos pueden distinguir una seña?','correct'=>'El movimiento, la ubicación, la orientación y componentes no manuales.','choices'=>['Solo la rapidez con la que se mueve la mano.','Únicamente el color de la ropa.','Solo la mano dominante, sin importar el contexto.'],'explanation'=>'La configuración manual es solo una parte: ubicación, orientación, movimiento y señales no manuales pueden cambiar la seña.','source'=>'Estudio sobre reconocimiento de LSM','source_url'=>'https://pmc.ncbi.nlm.nih.gov/articles/PMC11214366/'],
        ['prompt'=>'¿Existe una única lengua de señas que se use igual en todos los países?','correct'=>'No. Hay distintas lenguas de señas, asociadas a comunidades y contextos diferentes.','choices'=>['Sí, todas las comunidades usan las mismas señas.','Sí, el alfabeto manual es universal y reemplaza toda lengua.','No, porque las lenguas de señas no tienen vocabulario.'],'explanation'=>'Las lenguas de señas no son universales; la LSM pertenece a su comunidad lingüística y contexto.','source'=>'SIL México','source_url'=>'https://mexico.sil.org/es/lengua_cultura/lenguas-de-se%C3%B1as-en-m%C3%A9xico'],
        ['prompt'=>'¿Qué puede concluir por sí sola una cámara que localiza puntos de la mano?','correct'=>'Puede estimar la geometría y presencia de la mano, pero no demostrar que una seña sea correcta en LSM.','choices'=>['Puede certificar el significado de cualquier frase en LSM.','Puede validar la gramática y las expresiones faciales aunque no las mida.','Puede sustituir a una persona competente en LSM.'],'explanation'=>'Un detector de puntos de mano no evalúa por sí solo significado, gramática, expresión facial ni contexto.','source'=>'Alcance del detector de práctica Senix','source_url'=>''],
        ['prompt'=>'¿Cuál es una buena forma de validar una guía de señas para aprender LSM?','correct'=>'Revisarla con personas sordas o docentes competentes en LSM y citar una fuente confiable.','choices'=>['Dar por correcta cualquier animación generada automáticamente.','Traducir cada frase española palabra por palabra.','Considerar que el reconocimiento de una postura prueba el significado.'],'explanation'=>'Una pose 3D puede servir como referencia visual, pero el contenido lingüístico necesita revisión comunitaria y fuentes.','source'=>'Criterio editorial de Senix','source_url'=>'']
    ];
    shuffle($bank);$picked=array_slice($bank,0,3);$client=[];$stored=[];
    foreach($picked as $index=>$question){$labels=$question['choices'];$labels[]=$question['correct'];shuffle($labels);$questionId='q'.($index+1);$choices=[];$correct='';foreach($labels as $label){$choiceId='c'.bin2hex(random_bytes(4));$choices[]=['id'=>$choiceId,'label'=>$label];if($label===$question['correct'])$correct=$choiceId;}$client[]=['id'=>$questionId,'prompt'=>$question['prompt'],'choices'=>$choices];$stored[$questionId]=['prompt'=>$question['prompt'],'correct'=>$correct,'choices'=>array_column($choices,'label','id'),'answered'=>false,'explanation'=>$question['explanation'],'source'=>$question['source'],'source_url'=>$question['source_url']];}
    return ['client'=>$client,'stored'=>$stored];
}function learn_timezone(string $value=''): string {
    $fallback='America/Mexico_City';
    return $value!=='' && in_array($value,DateTimeZone::listIdentifiers(),true) ? $value : $fallback;
}
function learn_curriculum_completed(int $userId): array {
    learn_ensure_tables();
    $q=learn_db()->prepare('SELECT lesson_key FROM user_curriculum_progress WHERE user_id=? ORDER BY lesson_order');
    $q->execute([$userId]);
    return array_column($q->fetchAll(),'lesson_key');
}
function learn_curriculum_can_start(int $userId,string $key): bool {
    $all=learn_curriculum(); $index=null;
    foreach($all as $i=>$item) if($item['key']===$key){$index=$i;break;}
    if($index===null)return false;
    if($index===0)return true;
    $q=learn_db()->prepare('SELECT COUNT(*) FROM user_curriculum_progress WHERE user_id=? AND lesson_key=?');
    $q->execute([$userId,$all[$index-1]['key']]);
    return (int)$q->fetchColumn()===1;
}
function learn_save_curriculum_completion(int $userId,string $key,string $timezone,int $quizScore=0,int $quizTotal=0): array {
    global $achievementModel,$userModel;
    learn_ensure_tables();$item=null;foreach(learn_curriculum() as $row)if($row['key']===$key){$item=$row;break;}
    if(!$item)throw new RuntimeException('Lección no válida.');
    $quizTotal=max(0,min(3,$quizTotal));$quizScore=max(0,min($quizTotal,$quizScore));$baseXp=(int)$item['xp'];$bonusCap=(int)round($baseXp*.5);$quizBonus=$quizTotal>0?(int)round($bonusCap*($quizScore/$quizTotal)):0;
    $db=learn_db();$tz=learn_timezone($timezone);$first=false;$xpAwarded=0;$level=1;$previousLevel=1;
    $db->beginTransaction();
    try{
        $db->prepare('SELECT id FROM users WHERE id=? FOR UPDATE')->execute([$userId]);
        if(!learn_curriculum_can_start($userId,$key))throw new DomainException('Completa las lecciones anteriores para desbloquear esta.');
        $q=$db->prepare('SELECT xp_awarded FROM user_curriculum_progress WHERE user_id=? AND lesson_key=?');$q->execute([$userId,$key]);$first=$q->fetchColumn()===false;
        if($first){
            $xpAwarded=$baseXp+$quizBonus;
            $db->prepare('INSERT INTO user_curriculum_progress(user_id,lesson_key,lesson_order,section_no,lesson_index,xp_awarded,timezone,completed_at_utc) VALUES(?,?,?,?,?,?,?,UTC_TIMESTAMP())')->execute([$userId,$key,$item['order'],$item['section'],$item['index'],$xpAwarded,$tz]);
            $q=$db->prepare('SELECT level,xp,total_xp FROM user_stats WHERE user_id=? FOR UPDATE');$q->execute([$userId]);$stats=$q->fetch();if(!$stats)throw new RuntimeException('No existen estadísticas para la cuenta.');
            $xp=(int)$stats['xp']+$xpAwarded;$total=(int)$stats['total_xp']+$xpAwarded;$level=(int)$stats['level'];$previousLevel=$level;
            while($level<MAX_LEVEL&&$xp>=xp_for_level($level)){$xp-=xp_for_level($level);$level++;}
            $db->prepare('UPDATE user_stats SET xp=?,total_xp=?,rank_points=rank_points+?,level=?,lessons_completed=lessons_completed+1 WHERE user_id=?')->execute([$xp,$total,$xpAwarded,$level,$userId]);
        }else{$q=$db->prepare('SELECT level FROM user_stats WHERE user_id=?');$q->execute([$userId]);$level=(int)$q->fetchColumn();}
        $db->commit();
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    if($first){senix_community_record_event($db,$userId,'lesson','Completó una lección de aprendizaje','Terminó la práctica guiada de la sección '.(int)$item['section'].'.','curriculum:'.$key);for($eventLevel=$previousLevel+1;$eventLevel<=$level;$eventLevel++)senix_community_record_event($db,$userId,'level','Subió al nivel '.$eventLevel,'Un nuevo nivel en tu camino de aprendizaje.','level:'.$eventLevel);}
    if(isset($userModel))$userModel->updateStreak($userId,$tz);if(isset($achievementModel))$achievementModel->checkAll($userId);
    return ['first'=>$first,'xp'=>$xpAwarded,'xp_base'=>$first?$baseXp:0,'quiz_bonus'=>$first?$quizBonus:0,'level'=>$level,'quiz_score'=>$quizScore,'quiz_total'=>$quizTotal];
}function learn_record_practice(int $userId, int $xp=0, string $timezone=''): void {
    global $userModel,$achievementModel;
    try{if(isset($userModel)&&method_exists($userModel,'updateStreak'))$userModel->updateStreak($userId,learn_timezone($timezone));if($xp>0&&isset($userModel))$userModel->addXP($userId,$xp);if(isset($achievementModel))$achievementModel->checkAll($userId);}catch(Throwable $e){error_log('[Senix practice record] '.$e->getMessage());}
}



