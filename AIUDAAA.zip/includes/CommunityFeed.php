<?php
/** Shared activity log for public learning milestones. */

if (basename($_SERVER['PHP_SELF'] ?? '') === 'CommunityFeed.php') {
    http_response_code(403);
    exit('Acceso denegado');
}

function senix_community_ensure_event_table(PDO $db): void {
    static $ready = false;
    if ($ready) return;
    $db->exec("CREATE TABLE IF NOT EXISTS community_activity_events (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        event_type ENUM('lesson','level','achievement') NOT NULL,
        event_key VARCHAR(120) DEFAULT NULL,
        title VARCHAR(180) NOT NULL,
        details VARCHAR(255) DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(id),
        UNIQUE KEY uq_community_event_key(user_id,event_key),
        KEY idx_community_event_created(created_at),
        KEY idx_community_event_user(user_id),
        CONSTRAINT fk_community_event_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $ready = true;
}

function senix_community_record_event(PDO $db, int $userId, string $type, string $title, string $details = '', ?string $key = null): void {
    if ($userId < 1 || !in_array($type, ['lesson', 'level', 'achievement'], true)) return;
    senix_community_ensure_event_table($db);
    $cut = static fn(string $value, int $limit): string => function_exists('mb_substr') ? mb_substr($value, 0, $limit, 'UTF-8') : substr($value, 0, $limit);
    $stmt = $db->prepare('INSERT INTO community_activity_events(user_id,event_type,event_key,title,details) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)');
    $stmt->execute([$userId, $type, $key, $cut($title, 180), $cut($details, 255)]);
}
