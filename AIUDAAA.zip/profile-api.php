<?php
ob_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/profile-tools.php';
require_once __DIR__ . '/includes/api-tools.php';

function profile_json(array $payload, int $status = 200): never {
    api_json($payload, $status);
}

function profile_length(string $value): int {
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

/**
 * Guarda el avatar ya recortado por el navegador. Se recibe como texto para
 * evitar los rechazos intermitentes del hosting a peticiones multipart.
 */
function profile_save_data_avatar(string $value, int $userId): string {
    if (!preg_match('~^data:image/jpeg;base64,([A-Za-z0-9+/=]+)$~', $value, $match)) {
        throw new DomainException('No se pudo leer la foto preparada. Vuelve a seleccionarla.');
    }

    $binary = base64_decode($match[1], true);
    if ($binary === false || $binary === '' || strlen($binary) > 700 * 1024) {
        throw new DomainException('La foto preparada es demasiado grande. Prueba con otra imagen.');
    }

    $dimensions = @getimagesizefromstring($binary);
    if (!$dimensions || ($dimensions['mime'] ?? '') !== 'image/jpeg') {
        throw new DomainException('La foto preparada no tiene un formato válido.');
    }
    if ((int)$dimensions[0] < 128 || (int)$dimensions[1] < 128) {
        throw new DomainException('La foto es demasiado pequeña. Usa al menos 128 × 128 px.');
    }

    $directory = rtrim(UPLOADS_PATH, '/\\') . DIRECTORY_SEPARATOR . 'avatars';
    if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('No se pudo preparar la carpeta de fotos.');
    }

    $filename = 'avatar_' . $userId . '_' . time() . '_' . bin2hex(random_bytes(3)) . '.jpg';
    $destination = $directory . DIRECTORY_SEPARATOR . $filename;
    if (@file_put_contents($destination, $binary, LOCK_EX) === false) {
        throw new RuntimeException('No se pudo guardar la foto.');
    }
    @chmod($destination, 0644);
    return $filename;
}

api_prepare();
api_require_login($auth, 'Tu sesión expiró. Recarga la página para editar tu perfil.');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'GET' && ($_GET['action'] ?? '') === 'token') {
    profile_json(['success' => true, 'csrf_token' => (string)($_SESSION['learn_csrf'] ?? '')]);
}
if ($method !== 'POST') profile_json(['error' => 'Método no permitido.'], 405);
api_verify_csrf();

try {
    profile_ensure_schema($pdo);
    $userId = (int)currentUserId();
    $fullName = trim(str_replace("\0", '', (string)($_POST['full_name'] ?? '')));
    $bio = trim(str_replace("\0", '', (string)($_POST['bio'] ?? '')));
    $frame = profile_frame_value($_POST['profile_frame'] ?? 'none');
    $currentProfile = $userModel->find($userId) ?: [];
    if (!in_array($frame, profile_unlocked_frames($pdo, $userId, (string)($currentProfile['profile_frame'] ?? 'none')), true)) {
        throw new DomainException('Ese marco está bloqueado. Desbloquea el logro que aparece en tu perfil.');
    }

    $nameLength = profile_length($fullName);
    if ($nameLength < 2 || $nameLength > 80) {
        throw new DomainException('El nombre debe tener entre 2 y 80 caracteres.');
    }
    if (profile_length($bio) > 150) {
        throw new DomainException('La descripción no puede superar 150 caracteres.');
    }

    $changes = [
        'full_name' => $fullName,
        'bio' => $bio === '' ? null : $bio,
        'profile_frame' => $frame,
    ];

    $avatarData = trim((string)($_POST['avatar_data'] ?? ''));
    if ($avatarData !== '') {
        $changes['avatar'] = profile_save_data_avatar($avatarData, $userId);
    }

    $file = $_FILES['avatar'] ?? null;
    if ($avatarData === '' && is_array($file) && (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        if ((int)($file['size'] ?? 0) > MAX_AVATAR_SIZE) {
            throw new DomainException('La foto no puede superar 2 MB.');
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? (string)finfo_file($finfo, (string)($file['tmp_name'] ?? '')) : '';
        if ($finfo) finfo_close($finfo);
        if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
            throw new DomainException('Usa una imagen JPG, PNG o WEBP.');
        }

        $dimensions = @getimagesize((string)($file['tmp_name'] ?? ''));
        if (!$dimensions) {
            throw new DomainException('No se pudo leer la imagen seleccionada.');
        }
        [$width, $height] = $dimensions;
        $shortSide = min($width, $height);
        $longSide = max($width, $height);
        if ($shortSide < 128) {
            throw new DomainException('La foto es demasiado pequeña. Usa al menos 128 × 128 px.');
        }
        if ($longSide > 4096) {
            throw new DomainException('La foto es demasiado grande. El lado mayor puede medir hasta 4096 px.');
        }
        if ($longSide / $shortSide > 4) {
            throw new DomainException('La foto es demasiado alargada para adaptarla sin perder demasiado contenido.');
        }

        $uploader = new Uploader('avatars');
        $uploaded = $uploader->uploadAvatar($file, $userId);
        if (empty($uploaded['success'])) {
            throw new DomainException((string)($uploaded['error'] ?? 'No se pudo guardar la foto.'));
        }
        $changes['avatar'] = (string)$uploaded['filename'];
    }

    $bannerFile = $_FILES['banner'] ?? null;
    if (is_array($bannerFile) && (int)($bannerFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        $upload = (new Uploader('banners'))->uploadImage($bannerFile, ['max_size'=>4*1024*1024,'max_width'=>3000,'max_height'=>1200,'prefix'=>'banner']);
        if (empty($upload['success'])) throw new DomainException((string)($upload['error'] ?? 'No se pudo guardar el banner.'));
        $changes['profile_banner'] = basename((string)$upload['filename']);
    }
    if (!$userModel->update($userId, $changes)) {
        throw new RuntimeException('No se pudo actualizar el perfil.');
    }

    $profile = $userModel->find($userId) ?: [];
    profile_json([
        'success' => true,
        'message' => 'Tu perfil quedó actualizado.',
        'profile' => profile_client_payload($profile),
    ]);
} catch (DomainException $e) {
    profile_json(['error' => $e->getMessage()], 422);
} catch (Throwable $e) {
    error_log('[Senix profile] ' . $e->getMessage());
    profile_json(['error' => 'No se pudo actualizar el perfil. Inténtalo de nuevo.'], 500);
}

