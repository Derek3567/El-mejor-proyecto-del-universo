/* ==========================================================
 * Senix v2.0 — Service Worker (PWA)
 * Modo offline y caché inteligente
 * ========================================================== */

const CACHE_NAME    = 'senix-v2.0.3';
const CACHE_STATIC  = 'senix-static-v15';
const CACHE_DYNAMIC = 'senix-dynamic-v9';
const CACHE_IMAGES  = 'senix-images-v3';

const STATIC_ASSETS = [
    '/offline.php',
    '/manifest.json',
    '/assets/css/style.css',
    '/assets/css/animations.css',
    '/assets/img/logo.svg',
    '/assets/css/menu.css',
    '/assets/css/menu-warm.css',
    '/assets/js/menu.js',
    '/assets/js/camera-devices.js',
    '/assets/js/senix-sound.js',
    '/assets/js/responsive-robot.js',
    '/assets/css/priority-2026.css',
    '/assets/audio/ambient.wav',
    '/assets/audio/click.wav',
    '/assets/audio/transition.wav',
    '/assets/audio/success.wav',
    '/assets/audio/error.wav',
    '/assets/js/mini-game.js',
    '/assets/css/mini-game.css',
    '/assets/vendor/three.min.js',
    '/assets/js/sign-schema.js',
    '/assets/js/sign-viewer.js',
    '/assets/css/sign-viewer.css',
    '/assets/data/signs-lsm.json'
];

const CDN_ASSETS = [
    'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap',
    'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js',
    'https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js',
    'https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js'
];

// ==========================================================
// INSTALL
// ==========================================================
self.addEventListener('install', event => {
    console.log('[SW] Instalando...');
    
    event.waitUntil(
        caches.open(CACHE_STATIC)
            .then(cache => {
                return Promise.all(STATIC_ASSETS.map(url =>
                    fetch(url, { cache: 'no-store' })
                        .then(response => response.ok ? cache.put(url, response) : null)
                        .catch(() => null)
                ));
            })
            .then(() => {
                return caches.open(CACHE_DYNAMIC).then(cache => {
                    return Promise.all(
                        CDN_ASSETS.map(url =>
                            fetch(url, { mode: 'cors' })
                                .then(res => res.ok ? cache.put(url, res) : null)
                                .catch(() => null)
                        )
                    );
                });
            })
            .then(() => self.skipWaiting())
    );
});

// ==========================================================
// ACTIVATE
// ==========================================================
self.addEventListener('activate', event => {
    console.log('[SW] Activando...');
    
    const validCaches = [CACHE_STATIC, CACHE_DYNAMIC, CACHE_IMAGES];
    
    event.waitUntil(
        caches.keys()
            .then(names => {
                return Promise.all(
                    names.map(name => {
                        if (!validCaches.includes(name)) {
                            console.log('[SW] Borrando caché vieja:', name);
                            return caches.delete(name);
                        }
                    })
                );
            })
            .then(() => self.clients.claim())
    );
});

// ==========================================================
// FETCH
// ==========================================================
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);
    
    // Ignorar requests no-GET
    if (request.method !== 'GET') return;
    
    // Ignorar extensiones de Chrome
    if (url.protocol === 'chrome-extension:') return;

    // Never cache PHP pages or API responses (including their CSRF tokens).
    if (url.origin === self.location.origin && (url.pathname === '/' || url.pathname.endsWith('.php')) && url.pathname !== '/offline.php') {
        if (request.mode === 'navigate') {
            event.respondWith(fetch(request).catch(async () =>
                await caches.match('/offline.php') || new Response('Sin conexión', { status: 503 })
            ));
        } else {
            event.respondWith(fetch(request).catch(() => new Response(
                JSON.stringify({ success: false, error: 'Sin conexión. Inténtalo de nuevo.' }),
                { status: 503, headers: { 'Content-Type': 'application/json; charset=utf-8' } }
            )));
        }
        return;
    }
    
    // API: network-first (siempre datos frescos)
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(networkFirst(request, CACHE_DYNAMIC));
        return;
    }
    
    // Imágenes: cache-first
    if (request.destination === 'image' || /\.(png|jpg|jpeg|gif|webp|svg|ico)$/i.test(url.pathname)) {
        event.respondWith(cacheFirst(request, CACHE_IMAGES));
        return;
    }
    
    // CSS, JS, fuentes: stale-while-revalidate
    if (/\.(css|js|woff2?|ttf|otf)$/i.test(url.pathname) || 
        url.hostname.includes('fonts.g') ||
        url.hostname.includes('cdn.jsdelivr')) {
        event.respondWith(staleWhileRevalidate(request, CACHE_STATIC));
        return;
    }
    
    // HTML/PHP: network-first con fallback a offline
    if (request.destination === 'document' || url.pathname.endsWith('.php')) {
        event.respondWith(networkFirstWithOffline(request));
        return;
    }
    
    // Por defecto: network-first
    event.respondWith(networkFirst(request, CACHE_DYNAMIC));
});

// ==========================================================
// ESTRATEGIAS
// ==========================================================

async function cacheFirst(request, cacheName) {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);
    if (cached) return cached;
    
    try {
        const response = await fetch(request);
        if (response.ok) {
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        return new Response('', { status: 503, statusText: 'Offline' });
    }
}

async function networkFirst(request, cacheName) {
    const cache = await caches.open(cacheName);
    
    try {
        const response = await fetch(request);
        if (response.ok) {
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        const cached = await cache.match(request);
        if (cached) return cached;
        return new Response('', { status: 503, statusText: 'Offline' });
    }
}

async function staleWhileRevalidate(request, cacheName) {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);
    
    const fetchPromise = fetch(request)
        .then(response => {
            if (response.ok) {
                cache.put(request, response.clone());
            }
            return response;
        })
        .catch(() => null);
    
    return cached || await fetchPromise || new Response('', { status: 503 });
}

async function networkFirstWithOffline(request) {
    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(CACHE_DYNAMIC);
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        const cached = await caches.match(request);
        if (cached) return cached;
        
        return await caches.match('/offline.php') || new Response('Sin conexión', { status: 503 });
    }
}

// ==========================================================
// BACKGROUND SYNC (para futuras sincronizaciones)
// ==========================================================
self.addEventListener('sync', event => {
    console.log('[SW] Sync:', event.tag);
    if (event.tag === 'sync-progress') {
        event.waitUntil(syncProgress());
    }
});

async function syncProgress() {
    // Aquí sincronizarías progreso guardado offline
    console.log('[SW] Sincronizando progreso...');
}

// ==========================================================
// PUSH NOTIFICATIONS
// ==========================================================
self.addEventListener('push', event => {
    const data = event.data ? event.data.json() : {};
    
    const options = {
        body: data.body || 'Nueva notificación de Senix',
        icon: '/assets/img/icon-192.png',
        badge: '/assets/img/badge-72.png',
        vibrate: [200, 100, 200],
        data: { url: data.url || '/menu.php' },
        actions: [
            { action: 'open', title: 'Abrir' },
            { action: 'close', title: 'Cerrar' }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification(data.title || 'Senix', options)
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    
    if (event.action === 'close') return;
    
    const url = event.notification.data.url || '/menu.php';
    
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then(clientList => {
                for (const client of clientList) {
                    if (client.url.includes(url) && 'focus' in client) {
                        return client.focus();
                    }
                }
                if (clients.openWindow) return clients.openWindow(url);
            })
    );
});

// ==========================================================
// MENSAJES DESDE LA PÁGINA
// ==========================================================
self.addEventListener('message', event => {
    if (event.data === 'skipWaiting') {
        self.skipWaiting();
    }
    if (event.data === 'clearCache') {
        caches.keys().then(names => {
            names.forEach(name => caches.delete(name));
        });
    }
});
